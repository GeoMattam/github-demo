# tools/extractor_tools.py
from typing import Dict, List
import docx

from tools.prompt_utils import extract_clean_json

def load_docx_tool(inputs: Dict) -> Dict:
    """
    Loads a .docx file and returns its raw text.
    """
    file_path = inputs["file_path"]
    doc = docx.Document(file_path)
    text = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
    return {"raw_text": text}


def extract_requirements_tool(inputs: Dict, run_llm, verbose=False) -> Dict:
    """
    Extracts requirement-like statements from raw text.
    """

    """ Requirement Extraction through simple method
    raw_text = inputs["raw_text"]
    paragraphs = [p.strip() for p in raw_text.split("\n") if p.strip()]
    requirements = []

    for idx, para in enumerate(paragraphs):
        if any(k in para.lower() for k in ["must", "shall", "should", "will", "ability to"]):
            requirements.append({
                "requirement_id": f"REQ-{idx + 1:03d}",
                "requirement_text": para
            })

    return {"requirements": requirements} 
    """

    # Requirement Extraction through prompt
    # Step 1: First get the requirement text in whole
    raw_text = inputs["raw_text"]

    # Step 3: Build the prompt
    prompt = f"""
        You are a business analyst reading a Business Requirements Document (BRD).

        Extract all the business requirements from the following text. For each requirement, return:

        - requirement_id: a unique ID (e.g., REQ-001, REQ-002...)
        - requirement_text: clear, concise statement of the requirement

        Only return a JSON list of requirements.

        Do not include code or markdown. Do not explain.

        Return a JSON array in this exact format:
        [
            {{
                "requirement_id": "REQ-001",
                "requirement_text": "Text of the extracted requirement"
            }},
            ...
        ]

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        BRD Content:
        ```{raw_text}```
    """.strip()

    # log the prompt
    # tool_logger.debug("[ClassifyRequirementTool] Requirements that need classification:\n" + prompt)

    response = run_llm(prompt)
    # tool_logger.debug("[ClassifyRequirementTool] LLM raw response:\n" + response)

    try:
        # llm_results = json.loads(response)
        llm_results = extract_clean_json(response)
    except Exception as e:
        # tool_logger.error(f"[ClassifyRequirementTool] Failed to parse LLM response: {e}")
        llm_results = []

    return {"requirements": llm_results}