# tools/classifier_tools.py
import logging
from typing import List, Dict
from utils.logger import get_logger
import json

from tools.prompt_utils import extract_clean_json

def classify_requirement_tool(extracted_requirements: List[Dict], run_llm, verbose=False) -> Dict:
    """
    Classify a requirement using Gemini and return its type.
    """

    # Step 1: First set up the logger
    """ tool_logger = get_logger(
        log_to_console=False,
        log_to_file=True,
        level=logging.DEBUG if verbose else logging.INFO
    ) """

    # Step 2: Build the requirements that needs classification
    req_lines = "\n".join([
        f'{req["requirement_id"]}: {req["requirement_text"]}' for req in extracted_requirements
    ])

    # tool_logger.debug("[ClassifyRequirementTool] Requirements that need classification:\n" + req_lines)

    # Step 3: Build the prompt
    prompt = f"""
        You are a senior business analyst.

        Below is a list of software requirements. Classify each requirement into one of the following types:
        - Functional
        - Non-Functional
        - System
        - External Integration
        - Compliance
        
        Also, Return a confidence score from 0.0 (unsure) to 1.0 (very confident)
        Also, Identify and Return the primary stakeholders relevant to the requirement (e.g., Customer, Compliance Officer, DevOps, Admin, End-user, API Partner, etc.)

        Return a JSON array in this exact format:
        [
            {{
                "requirement_id": "REQ-001",
                "requirement_type": "Functional",
                "confidence_score": 0.92,
                "stakeholders": ["Customer", "Admin"]
            }},
            ...
        ]

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        Requirement:
        ```{req_lines}```
    """.strip()

    # log the prompt
    # tool_logger.debug("[ClassifyRequirementTool] Requirements that need classification:\n" + prompt)

    response = run_llm(prompt)
    # tool_logger.debug("[ClassifyRequirementTool] LLM raw response:\n" + response)

    try:
        # llm_results = json.loads(response)
        llm_results = extract_clean_json(response)
    except Exception as e:
        # tool_logger.error(f"[ClassifyRequirementTool] Failed to parse LLM response: {e}")
        llm_results = []

    # Step 4: map the results back to the requirement id for each requirement
    result_map = {
        r["requirement_id"]: r for r in llm_results
    }

    for req in extracted_requirements:
        req_type = result_map.get(req["requirement_id"], "Unknown")
        req["requirement_type"] = req_type.get("requirement_type", "Unknown")
        req["confidence_score"] = req_type.get("confidence_score", 0.0)
        req["stakeholders"] = req_type.get("stakeholders", [])

        # tool_logger.info(f"[ClassifyRequirementTool] : {req['requirement_id']}: {req_type}")

    return {"classified_requirements": extracted_requirements}