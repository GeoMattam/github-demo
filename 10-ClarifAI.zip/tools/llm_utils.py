# tools/llm_utils.py
import google.generativeai as genai
import os

from utils.logger import get_logger

logger = get_logger()

genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
LLM_MODEL = "gemini-1.5-flash"

def call_gemini(prompt: str) -> str:
    logger.info(f"[call_gemini] Calling llm with model set as {LLM_MODEL}")

    model = genai.GenerativeModel(LLM_MODEL)
    response = model.generate_content(prompt)
    return response.text
