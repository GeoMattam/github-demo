# main.py
import sys
import os

# get the current directory of the file
current_dir = os.path.dirname(os.path.abspath(__file__))
# get the parent directory of the file by going one level up
parent_dir = os.path.dirname(current_dir)

# Add the parent directory to the sys path
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

from agents.extractor_agent import ExtractorAgent
from agents.classifier_agent import ClassifierAgent
from agents.validation_agent import ValidationAgent
from agents.user_story_agent import UserStoryAgent
from agents.gherkin_agent import GherkinAgent

from tools.llm_utils import call_gemini

if __name__ == "__main__":
    file_path = r"C:\137150\MyLabSpace\10-ClarifAI\sample_docs\Sample-BRD.docx"
    agent = ExtractorAgent(llm_caller=call_gemini)
    extracted = agent.run(file_path)

    from pprint import pprint
    pprint(extracted)
    len(extracted)

    agent = ClassifierAgent(llm_caller=call_gemini, verbose=True)
    classified = agent.run(extracted)

    agent = ValidationAgent(llm_caller=call_gemini)
    validated = agent.run(classified)

    agent = UserStoryAgent(llm_caller=call_gemini)
    user_stories = agent.run(validated)

    agent = GherkinAgent(llm_caller=call_gemini)
    gherkin_scenarios = agent.run(user_stories)
    