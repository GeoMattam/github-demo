from typing import List, Dict, Callable
import json
import logging

from tools.prompt_utils import extract_clean_json

# logger = logging.getLogger("RequirementAI")

class GherkinAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def run(self, inputs: Dict) -> Dict:
        user_stories: List[Dict] = inputs["user_stories"]
        # logger.info(f"Generating Gherkin scenarios for {len(user_stories)} user stories...")

        if not user_stories:
            return {"gherkin_scenarios": []}

        # Format prompt content
        formatted = "\n".join([f"""
                                Requirement ID: {story['requirement_id']}
                                User Story: {story['user_story']}
                                Acceptance Criteria:
                                - {'\\n- '.join(story['acceptance_criteria'])}
                                """.strip() for story in user_stories
        ])

        # Prompt Gemini
        prompt = f"""
        You are a test automation expert.

        For each requirement below, generate:
        - A Gherkin "Feature" name
        - One or two test "Scenario" titles
        - Steps in Gherkin format: Given / When / Then
        - A confidence_score between 0.0 and 1.0 indicating how accurate the Gherkin test is

        Return JSON only in this format:
        [
        {{
            "requirement_id": "REQ-001",
            "feature": "Login using OTP",
            "scenarios": [
            {{
                "name": "Successful login with valid OTP",
                "steps": [
                "Given the user enters a valid username",
                "And the user receives an OTP",
                "When the user enters the correct OTP",
                "Then the user is logged in"
                ]
            }}
            ],
            "confidence_score": 0.92
        }},
        ...
        ]

        DO NOT use markdown or triple backticks.
        DO NOT include explanation.
        Respond only with raw JSON.

        Requirements:
        {formatted}
        """.strip()

        # logger.debug("Gemini Gherkin prompt:\n" + prompt)

        llm_response = self.llm_caller(prompt)
        # logger.debug("Gemini response:\n" + llm_response)

        try:
            # parsed = json.loads(llm_response)
            parsed = extract_clean_json(llm_response)
        except Exception as e:
            # logger.error(f"Failed to parse Gherkin JSON: {e}")
            parsed = []

        return {"gherkin_scenarios": parsed}
