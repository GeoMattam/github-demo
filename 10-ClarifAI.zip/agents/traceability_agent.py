from typing import List, Dict
import logging

logger = logging.getLogger("RequirementAI")

class TraceabilityAgent:
    def run(self, inputs: Dict) -> Dict:
        classified = {r["requirement_id"]: r for r in inputs.get("classified", [])}
        validated = {r["requirement_id"]: r for r in inputs.get("validated", [])}
        user_stories = {r["requirement_id"]: r for r in inputs.get("user_stories", [])}
        gherkin = {r["requirement_id"]: r for r in inputs.get("gherkin_scenarios", [])}
        test_cases = {r["test_cases"]: r for r in inputs.get("test_cases", [])}

        # Index test cases by requirement_id
        # test_map = {}
        # for tc in test_cases:
        #     rid = tc.get("requirement_id")
        #     if rid:
        #         test_map.setdefault(rid, []).append(tc)

        all_ids = sorted(set(
            list(classified.keys())
            + list(validated.keys())
            + list(user_stories.keys())
            + list(gherkin.keys())
            + list(test_cases.keys())
        ))

        logger.info(f"Building traceability matrix for {len(all_ids)} requirements.")

        traceability = []

        for rid in all_ids:
            trace = {
                "requirement_id": rid,
                "requirement_text": classified.get(rid, {}).get("requirement_text", ""),
                "requirement_type": classified.get(rid, {}).get("requirement_type", ""),
                "confidence_score": classified.get(rid, {}).get("confidence_score", 0.0),
                "llm_check_passed": validated.get(rid, {}).get("validation", {}).get("llm_check_passed", False),
                "validation_issues": validated.get(rid, {}).get("validation", {}).get("issues", []),
                "user_story": user_stories.get(rid, {}).get("user_story", ""),
                "acceptance_criteria": user_stories.get(rid, {}).get("acceptance_criteria", []),
                "gherkin_feature": gherkin.get(rid, {}).get("feature", ""),
                "gherkin_scenarios": gherkin.get(rid, {}).get("scenarios", []),
            }
            traceability.append(trace)

        return {"traceability": traceability}
