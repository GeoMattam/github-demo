import streamlit as st
from io import StringIO
import logging
import os
import tempfile
import pandas as pd

from agents.extractor_agent import ExtractorAgent
from agents.classifier_agent import ClassifierAgent
from agents.validation_agent import ValidationAgent
from agents.user_story_agent import UserStoryAgent
from agents.gherkin_agent import GherkinAgent

from utils.logger import get_logger
from tools.llm_utils import call_gemini

st.set_page_config(page_title="ClarifAI Wizard", layout="wide")

# --- Setup Logging ---
@st.cache_resource
def setup_logger():
    log_stream = StringIO()
    st.session_state["log_stream"] = log_stream
    os.makedirs("logs", exist_ok=True)
    logger = logging.getLogger("ClarifAI")
    logger.setLevel(logging.DEBUG)
    if not logger.handlers:
        file_handler = logging.FileHandler("logs/ClarifAI.log")
        stream_handler = logging.StreamHandler(log_stream)
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        file_handler.setFormatter(formatter)
        stream_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        logger.addHandler(stream_handler)
        logger.propagate = False
    return logger, log_stream

logger, log_stream = setup_logger()

# --- Session State ---
for key in ["extracted", "classified", "validated", "user_stories", "gherkin_scenarios"]:
    if key not in st.session_state:
        st.session_state[key] = None

# --- Wizard Navigation State ---
if "step" not in st.session_state:
    st.session_state.step = 1

def next_step():
    st.session_state.step += 1

def prev_step():
    st.session_state.step -= 1

step = st.session_state.step
total_steps = 6

# Optional: Progress Indicator
st.progress(step / total_steps)

# --- Step 1: Upload and Extract ---
if step == 1:
    st.title("ClarifAI - Step 1: Upload BRD & Extract Requirements")
    uploaded_file = st.file_uploader("Upload a `.docx` or `.pdf` BRD document", type=["docx", "pdf"])
    if uploaded_file and st.button("Extract Requirements"):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(uploaded_file.read())
            temp_path = tmp.name
        agent = ExtractorAgent(llm_caller=call_gemini)
        extracted = agent.run(temp_path)
        st.session_state["extracted"] = extracted
        st.success(f"Extracted {len(extracted)} candidate requirements.")
        st.json(extracted)

    st.button("Next", on_click=next_step)

# --- Step 2: Classify ---
elif step == 2:
    st.title("Step 2: Classify Requirements")
    if st.session_state["extracted"]:
        min_conf = st.slider("Min confidence", 0.0, 1.0, 0.0, 0.05)
        raw_reqs = st.session_state["extracted"]
        extracted_requirements = []
        for idx, r in enumerate(raw_reqs):
            if isinstance(r, dict):
                extracted_requirements.append(r)
            else:
                extracted_requirements.append({
                    "requirement_id": f"REQ-{idx+1:03d}",
                    "requirement_text": str(r).strip()
                })
        agent = ClassifierAgent(llm_caller=call_gemini)
        result = agent.run(extracted_requirements)
        st.session_state["classified"] = result["classified_requirements"]
        for req in result["classified_requirements"]:
            if req["confidence_score"] < min_conf:
                continue
            st.markdown(f"**{req['requirement_id']}** — {req['requirement_type']} ({req['confidence_score']:.2f})")
            st.markdown(f"> {req['requirement_text']}")
            st.progress(req["confidence_score"])
            st.markdown("---")
    st.button("Previous", on_click=prev_step)
    st.button("Next", on_click=next_step)

# --- Step 3: Validate ---
elif step == 3:
    st.title("Step 3: Validate Requirements")
    if st.session_state["classified"]:
        agent = ValidationAgent(llm_caller=call_gemini)
        result = agent.run({"classified_requirements": st.session_state["classified"]})
        st.session_state["validated"] = result["validated_requirements"]
        for req in result["validated_requirements"]:
            issues = req.get("validation", {}).get("issues", [])
            passed = req.get("validation", {}).get("llm_check_passed", False)
            st.markdown(f"**{req['requirement_id']}** — {'✅ Valid' if passed else '❌ Issues'}")
            st.markdown(f"> {req['requirement_text']}")
            if issues:
                st.markdown("**Issues:**")
                for i in issues:
                    st.markdown(f"- {i}")
            st.markdown("---")
    st.button("Previous", on_click=prev_step)
    st.button("Next", on_click=next_step)

# --- Step 4: User Stories ---
elif step == 4:
    st.title("Step 4: Generate User Stories")
    if st.session_state["validated"]:
        min_conf = st.slider("Min story confidence", 0.0, 1.0, 0.0, 0.05)
        agent = UserStoryAgent(llm_caller=call_gemini)
        result = agent.run({"validated_requirements": st.session_state["validated"]})
        st.session_state["user_stories"] = result["user_stories"]
        for story in result["user_stories"]:
            if story["confidence_score"] < min_conf:
                continue
            st.markdown(f"**{story['requirement_id']}** — Confidence: `{story['confidence_score']:.2f}`")
            st.markdown(f"> *{story['user_story']}*")
            st.markdown("**Acceptance Criteria:**")
            for ac in story["acceptance_criteria"]:
                st.markdown(f"- {ac}")
            st.progress(story["confidence_score"])
            st.markdown("---")
    st.button("Previous", on_click=prev_step)
    st.button("Next", on_click=next_step)

# --- Step 5: Gherkin ---
elif step == 5:
    st.title("Step 5: Generate Gherkin Scenarios")
    if st.session_state.get("user_stories"):
        min_conf = st.slider("Minimum confidence", 0.0, 1.0, 0.0, 0.05)
        agent = GherkinAgent(llm_caller=call_gemini)
        result = agent.run({"user_stories": st.session_state["user_stories"]})
        st.session_state["gherkin_scenarios"] = result["gherkin_scenarios"]
        for item in result["gherkin_scenarios"]:
            if item.get("confidence_score", 0.0) < min_conf:
                continue
            st.markdown(f"### Feature: {item['feature']} ({item['requirement_id']}) — `{item.get('confidence_score', 0.0):.2f}`")
            st.progress(item.get("confidence_score", 0.0))
            for scenario in item.get("scenarios", []):
                st.markdown(f"**Scenario: {scenario['name']}**")
                for step in scenario.get("steps", []):
                    st.markdown(f"- {step}")
            feature_text = f"Feature: {item['feature']}\n\n"
            for s in item["scenarios"]:
                feature_text += f"  Scenario: {s['name']}\n"
                for step in s["steps"]:
                    feature_text += f"    {step}\n"
            st.download_button(
                label=f"Download {item['requirement_id']}.feature",
                data=feature_text,
                file_name=f"{item['requirement_id']}.feature",
                mime="text/plain"
            )
    else:
        st.warning("User stories not available.")
    st.button("Previous", on_click=prev_step)
    st.button("Next", on_click=next_step)

# --- Step 6: Logs ---
elif step == 6:
    st.title("Step 6: Execution Logs")
    auto = st.checkbox("Auto-refresh logs", value=True)
    out = st.empty()
    log_stream = st.session_state.get("log_stream", StringIO())
    if auto:
        import time
        for i in range(3):
            out.text_area("Logs", value=log_stream.getvalue(), height=400, key=f"log_output_auto_{i}", disabled=True)
            time.sleep(1)
    else:
        out.text_area("Logs", value=log_stream.getvalue(), height=400, key="log_output_manual", disabled=True)
    st.button("Previous", on_click=prev_step)
