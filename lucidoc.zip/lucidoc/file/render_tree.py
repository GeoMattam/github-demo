import os
from config import load_config

config = load_config()

def render_tree(files, markdown=False, include_size=False, base_path=None):
    """
    Renders the list of files as a tree structure, similar to the Unix 'tree' command.

    :param files: List of file paths to be rendered as a tree.
    :param markdown: Boolean indicating whether to render file names as Markdown links.
    :param include_size: Boolean indicating whether to include the file size in bytes.
    :return: A string representing the tree structure.
    """
    tree = {}
    for file_path in files:
        if base_path is None:
            base_path = config["lucidoc"]["input_path"]

        # get the path relative to config.input_path
        file = os.path.relpath(file_path, base_path)

        parts = file.split(os.sep)
        current = tree
        for part in parts:
            if part not in current:
                current[part] = {}
            current = current[part]

    def build_tree_string(current, path="", indent=""):
        tree_str = ""
        keys = sorted(current.keys())

        for index, key in enumerate(keys):
            is_last = index == len(keys) - 1
            prefix = "└── " if is_last else "├── "
            relative_path = os.path.join(path, key)

            # Determine if we need to add file size
            size_str = ""
            if include_size and not current[key]:  # Only files, not directories
                file_size = os.path.getsize(base_path / relative_path)
                size_str = f" [{file_size} bytes]"

            if markdown and not current[key]:
                # Render as markdown link if markdown is enabled and it's a file
                tree_str += f"{indent}{prefix}[{key}]({relative_path}){size_str}\n"
            else:
                tree_str += f"{indent}{prefix}{key}{size_str}\n"

            new_indent = indent + ("    " if is_last else "│   ")
            tree_str += build_tree_string(current[key], relative_path, new_indent)
        return tree_str

    return build_tree_string(tree)