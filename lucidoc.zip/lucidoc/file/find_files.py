import os
import subprocess
from pathlib import Path
from config import load_config

config = load_config()

def find_files(input_path: Path = None):

    if input_path is None:
        input_path = config["lucidoc"]["input_path"]

    return convert_str_array_to_path_array(
        get_regular_folder_files(input_path), input_path
    )

def get_regular_folder_files(folder_path):
    """
    Recursively finds all files in a regular folder (not a git repository).

    :param folder_path: Path to the folder to list files from.
    :return: A list of file paths relative to the root of the folder.
    """
    files = []
    for root, _, filenames in os.walk(folder_path):
        for filename in filenames:
            file_path = os.path.relpath(os.path.join(root, filename), start=folder_path)
            files.append(file_path)
    return files

def convert_str_array_to_path_array(str_array, input_path=config["lucidoc"]["input_path"]):
    return [Path(os.path.join(input_path, file)) for file in str_array]