import os
from pathlib import Path
from typing import List

from config import load_config
from file.find_files import find_files
from file.render_tree import render_tree
from document.generate_doc import generate_doc

from util import initialize_provider

import pprint

config = load_config()

def main():
    provider = initialize_provider()  # Initialize the provider

    input_path = (
        Path(config["lucidoc"]["input_path"]).resolve() if (config["lucidoc"]["input_path"] is not None) else None
    )

    output_path = (
        Path(config["lucidoc"]["output_path"]).resolve() if (config["lucidoc"]["output_path"] is not None) else None
    )

    project_name = input_path.name
    target_root_path = input_path
    
    print(f"Source path for document generation: [{target_root_path}]")
    print(f"Project Name of Source Files for document generation: [{project_name}]")
    print(f"Target path for generated documents : [{output_path}]")

    context_files = find_files(target_root_path)
    context_tree = render_tree(context_files, False, True, target_root_path)
    print(context_tree)

    for file in context_files:
        generate_doc(file, provider, context_tree)
    

if __name__ == "__main__":
    main()