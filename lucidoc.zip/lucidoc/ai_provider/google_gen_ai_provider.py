"""
This module provides an AI provider for interacting with the Google GenAI API.
"""

import os
import google.generativeai as genai
from .ai_provider import AIProvider

from config import load_config
config = load_config()

class GoogleGenAIProvider(AIProvider):
    """
    AI provider for interacting with the Google GenAI API.
    """

    def __init__(self):
        self.configure_genai()

    def configure_genai(self):
        """
        Configures the GenAI API using the environment variable GOOGLE_GENAI_API_KEY.
        """
        api_key = os.getenv("GOOGLE_API_KEY")
        genai.configure(api_key=api_key)

    def document_file(
        self, project_name, file_name, project_path, file_contents, notify_user_toast, tree
    ):
        """
        Documents a file using the Google GenAI API by providing the file path,
        file name, and its contents.

        Args:
            file_name (str): The name of the file to document.
            project_path (str): The project path where the file is located.
            file_contents (str): The contents of the file to be documented.
            notify_user_toast (function): A function to notify the user with a toast message.
            tree (QTreeWidget): The tree widget to update with the generated documentation

        Returns:
            str: The generated documentation for the file.
        """
        prompt = self.generate_prompt(project_name, file_name, project_path, file_contents, tree)

        # Prepare the request payload for the chat API
        try:
            model = genai.GenerativeModel(model_name=config["google"]["model"], 
                                          generation_config=genai.GenerationConfig(temperature=0.2, top_k=30, top_p=0.95))

            response = model.generate_content(prompt)  

            # Extract and return the documentation from the response
            return response.text

        except Exception as e:
            print(f"Error occurred while generating documentation: {e}")
            return None

    @property
    def function_block(self):
        """
        functions not implemented yet
        """
        return ""
