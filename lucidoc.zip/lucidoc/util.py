"""
This module contains utility functions that are used by the main script.
"""

import os
import sys
from pathlib import Path
from ai_provider.google_gen_ai_provider import GoogleGenAIProvider

def initialize_provider():
    """
    Initialize the AI provider.
    """

    provider_name = os.getenv("AI_PROVIDER").upper()

    # should work uppercase and lowercase, convert to uppercase
    if provider_name == "GOOGLE-GEMINI":
        print("-> Using Google Gemini AI provider")
        provider = GoogleGenAIProvider()

    elif provider_name == "GOOGLE-VERTEXAI":
        print("-> Using Google Vertex AI provider")
        provider = None

    elif provider_name == "OPENAI":
        print("-> Using OpenAI provider")
        provider =None

    else:
        print("Error: AI provider not found.")
        sys.exit(1)

    return provider
