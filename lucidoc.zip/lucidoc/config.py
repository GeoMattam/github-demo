import os
from dotenv import load_dotenv

def load_config():
    load_dotenv()
    return {
        "lucidoc": {
            "input_path": "C:/137150/MyLabSpace/03-ConversionSourceCodeRepository/fqhc",
            "output_path": "./lucidoc/generated_docs"
        },        
        "google": {
            "api_key": os.getenv("GOOGLE_API_KEY"),
            "base_url": os.getenv("GOOGLE_BASE_URL"),
            "model": "gemini-1.5-flash"
        },
        "openai": {
            "api_key": os.getenv("OPENAI_API_KEY"),
            "base_url": os.getenv("OPENAI_BASE_URL"),
            "model": "gpt-4o"
        }
    }