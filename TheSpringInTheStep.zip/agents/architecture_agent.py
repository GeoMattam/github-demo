"""

Builds dependency trees and identifies module boundaries.
Classifies components: controller, service, repository, config.

"""
import json
from collections import defaultdict
from rich import print

class ArchitectureAgent:
    def run(self, code_summary_path="output/code_summary.json"):
        print("[bold green]Running ArchitectureAgent...[/bold green]")

        with open(code_summary_path, "r", encoding="utf-8") as f:
            components = json.load(f)

        classified = defaultdict(list)           # role → list of class names
        call_graph = defaultdict(set)            # class → set of called classes
        reverse_call_graph = defaultdict(set)    # class → set of calling classes
        name_to_type = {}                        # class → list of roles
        pojo_usage = defaultdict(lambda: {
            "used_by": set(),
            "usage_types": defaultdict(set)
        })

        for comp in components:
            class_name = comp.get("class_name")
            if not class_name:
                continue

            comp_type = comp.get("component_type", [])
            if isinstance(comp_type, str):
                comp_type = [comp_type]

            comp_type = list(set(comp_type))  # Deduplicate roles

            for role in comp_type:
                if class_name not in classified[role]:
                    classified[role].append(class_name)

            name_to_type[class_name] = comp_type

        # Build call graph
        for comp in components:
            source = comp.get("class_name")
            if not source:
                continue

            for call in comp.get("calls", []):
                target = call.split(".")[0]
                if target:
                    call_graph[source].add(target)
                    reverse_call_graph[target].add(source)

        # Build POJO usage mapping
        for comp in components:
            class_name = comp.get("class_name")
            if not class_name:
                continue

            comp_type = comp.get("component_type", [])
            if isinstance(comp_type, str):
                comp_type = [comp_type]

            if any(role in ["POJO", "DTO", "Entity"] for role in comp_type):
                continue  # Skip POJO itself

            # Track field usage
            for field in comp.get("fields", []):
                pojo_type = field.get("type")
                if pojo_type and class_name:
                    pojo_usage[pojo_type]["used_by"].add(class_name)
                    pojo_usage[pojo_type]["usage_types"][class_name].add("field")

            # Track method param and return usage
            for method in comp.get("methods", []):
                for param_type in method.get("param_types", []):
                    if param_type and class_name:
                        pojo_usage[param_type]["used_by"].add(class_name)
                        pojo_usage[param_type]["usage_types"][class_name].add("method_param")

                return_type = method.get("return_type")
                if return_type and class_name:
                    pojo_usage[return_type]["used_by"].add(class_name)
                    pojo_usage[return_type]["usage_types"][class_name].add("return_type")

        # Convert all sets to sorted lists and clean Nones
        call_graph = {k: sorted([v for v in values if v]) for k, values in call_graph.items()}
        reverse_call_graph = {k: sorted([v for v in values if v]) for k, values in reverse_call_graph.items()}
        classified = {k: sorted(set(v)) for k, v in classified.items()}
        pojo_usage = {
            pojo: {
                "used_by": sorted([name for name in data["used_by"] if name]),
                "usage_types": {
                    k: sorted([v for v in usage if v]) for k, usage in data["usage_types"].items() if k
                }
            }
            for pojo, data in pojo_usage.items()
        }

        output = {
            "component_types": classified,
            "call_graph": call_graph,
            "reverse_call_graph": reverse_call_graph,
            "name_to_type": name_to_type,
            "pojo_usage": pojo_usage
        }

        with open("output/architecture.json", "w", encoding="utf-8") as f:
            json.dump(output, f, indent=2)

        print("[bold blue]Architecture written to output/architecture.json[/bold blue]")
        return output
    
# Optional direct run
if __name__ == "__main__":
    agent = ArchitectureAgent()
    agent.run("./output/code_summary.json")