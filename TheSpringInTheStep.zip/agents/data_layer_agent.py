"""

Analyzes JPA repositories and queries.
Maps entity relationships and joins.

"""