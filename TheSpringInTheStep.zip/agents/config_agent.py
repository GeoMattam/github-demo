"""

Parses application.yml and application.properties.
Summarizes active profiles, DB settings, and bean configurations.

"""
import os
import yaml
import json
from rich import print

class ConfigAgent:
    def run(self, project_path):
        print("[bold green]Running ConfigAgent...[/bold green]")

        config_data = {}

        yml_path = os.path.join(project_path, "src", "main", "resources", "application.yml")
        props_path = os.path.join(project_path, "src", "main", "resources", "application.properties")

        if os.path.exists(yml_path):
            with open(yml_path, "r") as f:
                config_data = yaml.safe_load(f)
        elif os.path.exists(props_path):
            with open(props_path, "r") as f:
                for line in f:
                    if "=" in line:
                        key, val = line.strip().split("=", 1)
                        config_data[key.strip()] = val.strip()

        with open("output/config_summary.json", "w") as f:
            json.dump(config_data, f, indent=2)

        print("[bold blue]Config summary written to output/config_summary.json[/bold blue]")
        return config_data

# Optional direct run
if __name__ == "__main__":
    agent = ConfigAgent()
    agent.run("C:/137150/MyLabSpace/03-ConversionSourceCodeRepository/Library-Management-System-main")