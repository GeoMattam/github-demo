"""

Parses application.yml and application.properties.
Summarizes active profiles, DB settings, and bean configurations.

"""