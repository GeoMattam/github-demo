"""

Finds and summarizes REST APIs using @RestController, @RequestMapping, etc.
Parses request/response types and HTTP verbs.

"""