"""

Scans Java files.
Extracts class names, methods, annotations using Tree-sitter or JavaParser.
Outputs a structured representation of the code (JSON).

This agent will:
    Walk through the Spring Boot project directory
    Parse Java files
    Extract class name, type (Controller, Service, etc.), methods, annotations
    Return a structured JSON output
"""
import os
import json
from parsers.java_parser import parse_java_file
from rich import print

class CodeReaderAgent:
    def run(self, project_path: str):
        print(f"[bold green]Scanning Java files in:[/bold green] {project_path}")
        java_data = []

        for root, _, files in os.walk(project_path):
            for file in files:
                if file.endswith(".java"):
                    full_path = os.path.join(root, file)
                    try:
                        result = parse_java_file(full_path)
                        java_data.append(result)
                    except Exception as e:
                        print(f"[red]Failed to parse {full_path}[/red]: {e}")
        
        output_path = "output/code_summary.json"
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(java_data, f, indent=2)
        
        print(f"[bold blue]Code summary written to {output_path}[/bold blue]")
        return java_data

# Optional direct run
if __name__ == "__main__":
    agent = CodeReaderAgent()
    agent.run("D:/05-BackupSourceCode/SourceCode/Microservices")
