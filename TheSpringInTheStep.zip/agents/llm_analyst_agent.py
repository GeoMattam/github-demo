"""

Uses Gemini to:
    Generate summaries of each component.
    Create architecture diagrams (PlantUML).
    Answer questions like “How does login flow work?”
    Create Markdown documentation.

"""
