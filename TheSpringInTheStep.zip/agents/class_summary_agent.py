"""

Uses Gemini to:
    Generate summaries of each component.
    Create architecture diagrams (PlantUML).
    Answer questions like “How does login flow work?”
    Create Markdown documentation.

"""
import os
import sys
import json
import google.generativeai as genai

# get the current directory of the file
current_dir = os.path.dirname(os.path.abspath(__file__))
# get the parent directory of the file by going one level up
parent_dir = os.path.dirname(current_dir)

# Add the parent directory to the sys path
if parent_dir not in sys.path:
    sys.path.append(parent_dir)
    
from tools.prompt_templates import CLASS_SUMMARY_PROMPT
from rich import print

class ClassSummaryAgent:
    def __init__(self):
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("Missing GOOGLE_API_KEY for api invocation")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel("gemini-1.5-flash")
    
    def run(self, architecture_path="output/architecture.json", code_summary_path="output/code_summary.json"):
        print("[bold green]Running LLMAnalystAgent...[/bold green]")

        with open(code_summary_path, "r") as f:
            code_summary = json.load(f)

        class_summaries = {}

        for cls in code_summary:
            class_name = cls["class_name"]

            if class_name is not None:
                print(f"[bold green]Processing Class {class_name}...[/bold green]")
                java_description = json.dumps(cls, indent=2)
                
                with open(cls["file"], "r") as f:
                    java_code = f.read()

                prompt = CLASS_SUMMARY_PROMPT.format(
                    description=json.dumps(java_description, indent=2),
                    code=java_code
                )

                try:
                    response = self.model.generate_content(prompt)
                    class_summaries[class_name] = response.text
                except Exception as e:
                    class_summaries[class_name] = f"(Error summarizing): {e}"

        with open("output/class_summaries.json", "w") as f:
            json.dump(class_summaries, f, indent=2)
        
        print("[bold blue]Summary written to output/architecture_summary.md[/bold blue]")
        return class_summaries

# Optional direct run
if __name__ == "__main__":
    agent = ClassSummaryAgent()
    agent.run()