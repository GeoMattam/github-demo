public class AccountHold {
	
	private String holdReferenceId;
	private double amount;
	
	public String getHoldReferenceId() {
		return holdReferenceId;
	}
	public void setHoldReferenceId(String holdId) {
		this.holdReferenceId = holdId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}

}

