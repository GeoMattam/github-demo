from tree_sitter import Language

Language.build_library(
  # Output path for the compiled library
  'build/my-languages.so',
  # Paths to the language repositories
  ['https://github.com/tree-sitter/tree-sitter-java']
)