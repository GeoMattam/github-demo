from dotenv import load_dotenv
from agents.code_reader_agent import CodeReaderAgent
from agents.architecture_agent import ArchitectureAgent

load_dotenv()

if __name__ == "__main__":
    agent = CodeReaderAgent()
    agent.run("C:/137150/MyLabSpace/03-ConversionSourceCodeRepository/Library-Management-System-main")
    arch_agent = ArchitectureAgent()
    arch_agent.run("output/code_summary.json")
