from dotenv import load_dotenv
from agents.code_reader_agent import CodeReaderAgent
from agents.architecture_agent import ArchitectureAgent

load_dotenv()

if __name__ == "__main__":
    agent = CodeReaderAgent()
    agent.run("D:/05-BackupSourceCode/SourceCode/Microservices/MOBOperations")
    arch_agent = ArchitectureAgent()
    arch_agent.run("output/code_summary.json")
