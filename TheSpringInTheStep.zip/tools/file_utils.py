import os

def list_java_files(path):
    java_files = []
    for root, _, files in os.walk(path):
        for file in files:
            if file.endswith(".java"):
                java_files.append(os.path.join(root,file))
    
    return java_files