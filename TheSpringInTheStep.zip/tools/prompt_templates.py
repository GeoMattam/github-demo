ARCHITECTURE_SUMMARY_PROMPT = """
You are a senior software architect. Based on the following Spring Boot code and architecture data, generate:

1. A high-level description of the application's layers and components.
2. How controllers interact with services and repositories.
3. Any notable flows or design patterns.
4. Important observations about the architecture.

ARCHITECTURE:
{architecture}

CODE SUMMARY:
{code_summary}
"""

CLASS_SUMMARY_PROMPT = """
You are an expert in Java Spring Boot. Analyze the description below and the class code given below.
Explain what the following class does, including:
- Its role (Controller, Service, etc.)
- Key methods and what they do
- Dependencies (fields and calls)
- When it is used and by whom

Class:
{description}

Code:
{code}
"""