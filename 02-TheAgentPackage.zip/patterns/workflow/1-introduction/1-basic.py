import time

from openai import OpenAI
from ollama import chat
from ollama import ChatResponse

start = time.time()

client = OpenAI(api_key="ollama", base_url="http://localhost:11434/v1")

completion = client.chat.completions.create(
    model="llama3.2",
     messages=[
        {"role": "system", "content": "You're a helpful assistant."},
        {
            "role": "user",
            "content": "Write a limerick about the Python programming language.",
        },
    ],
)

response = completion.choices[0].message.content
print(response)

""" completion = chat(

        model='llama3.2', 
        messages=[
            {"role": "system", "content": "You are a helpful assistant." },
            {
                'role': 'user',
                'content': "Write a limerick about python programming",
            },
        ],
    )

response = completion.message.content
print(response) """