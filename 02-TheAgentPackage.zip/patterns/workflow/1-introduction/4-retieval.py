import json
import os

from openai import OpenAI
from ollama import chat
from pydantic import BaseModel, Field

import pprint

import logging

# log file name
log = os.path.basename(__file__) + ".log"

# Setup logging configuration
logging.basicConfig(
    filename=log,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

client = OpenAI(api_key="ollama", base_url="http://localhost:11434/v1")
logger.info("Instanciated the llm client")

# ------------------------------------------------------------------------------------------------------------
# Define the tool (function) that we want to use for knowledge base retrieval
# ------------------------------------------------------------------------------------------------------------
def search_kb(question: str):
    """
    Load the whole knowledge base from the JSON file.
    (This is a mock function from demonstration, we don't search)
    """
    logger.info("Inside Tool (search_kb) to search the kb for user query")
    with open("./patterns/workflow/1-introduction/kb.json", "r") as f:
        return json.load(f)

# ------------------------------------------------------------------------------------------------------------
# step 1: call model with the search_kb tool defined
# ------------------------------------------------------------------------------------------------------------
tools = [{
    "type": "function",
    "function": {
        "name": "search_kb",
        "description": "Get the answer to the user's question from the knowledge base.",
        "parameters": {
            "type": "object",
            "properties": {
                "question": {"type": "string"},
            },
            "required": ["question"],
            "additionalProperties": False
        },
        "strict": True
    },
}]

system_prompt = "You are a helpful assistant that answer questions from the knowledge base about our e-commerce store."

messages=[
    {"role": "system", "content": system_prompt },
    {"role": "user", "content": "What is the return policy?"},
]

completion = client.chat.completions.create(
    model="llama3.1",
    messages=messages,
    tools=tools,
)

# ------------------------------------------------------------------------------------------------------------
# step 2: model decides to call function(s)
# ------------------------------------------------------------------------------------------------------------
# pprint.pprint(completion.model_dump())
logger.info(completion.model_dump())

# ------------------------------------------------------------------------------------------------------------
# step 3: Execute the search_kb function
# Please note that we call the function ourself, the AI does not call the function it only passes back the 
# functon name to call and the arguments. We use that call the function and also build the memory by addind
# to the messages object the message got back from the llm and also the result for from the tool call we made
# to keep building on the memiory and contect
# ------------------------------------------------------------------------------------------------------------
def call_function(name, args):
    if name == "search_kb":
        return search_kb(**args)

for tool_call in completion.choices[0].message.tool_calls:
    name = tool_call.function.name # name of the function got back from the llm based on the available tools and user question
    args = json.loads(tool_call.function.arguments) # arguments is always in the form of JSON - OpenAI
    
    # Memory: Following the message syntax add the new output to the messages list for context
    messages.append(completion.choices[0].message)

    result = call_function(name, args)

    messages.append({"role": "tool", "tool_call_id": tool_call.id, "content": str(result)}) # in case of OpenAI you can also add the tool_id
    # messages.append({"role": "tool", "content": str(result)}) # in case of llama
    pprint.pprint(messages)

# ------------------------------------------------------------------------------------------------------------
# step 4: Supply the result and call the model again
# Now we have the full context that we need to answer the intial question the user. We will use structure output
# again from the final answer from the llm
# ------------------------------------------------------------------------------------------------------------
class KBResponse(BaseModel):
    answer: str = Field(description="The answer to the user's question.")
    source: int = Field(description="The record id of the answer.")

# now we will be calling the model again, but this time not we will not be sending just the original message but
# we will be sending the entire context available - the orginal message, tools available, along with the tool call 
# information obtained from the first call to the llm and the result obtained from executing the tool call to the llm
# and will be asking for the response from the llm in the structure output format we have defined namely WeatherResponse
completion_final = client.beta.chat.completions.parse(
    model="llama3.1",
    messages=messages,
    tools=tools,
    response_format=KBResponse,
)

# ------------------------------------------------------------------------------------------------------------
# step 5: Checkthe model response
# ------------------------------------------------------------------------------------------------------------
final_response = completion_final.choices[0].message.parsed
# final_response = KBResponse.model_validate_json(completion_final.message.content) # in case of llama library
print(f"Answer:{final_response.answer}\nAnswer Source:{final_response.source}\n")

# ------------------------------------------------------------------------------------------------------------
# Question that does not trigger the tool
# ------------------------------------------------------------------------------------------------------------
messages=[
    {"role": "system", "content": system_prompt },
    {"role": "user", "content": "What is the current weather in London?"},
]

completion_oocontext = client.chat.completions.create(
    model="llama3.1",
    messages=messages,
    tools=tools,
)

pprint.pprint(completion_oocontext.choices[0].message.content)