1. Introduction

“Reach Health” is a USA-based charitable organization focused on enhancing primary healthcare in remote and underserved regions, with current operations in Kenya and Tanzania. Our mission is to support local healthcare facilities by facilitating communication with volunteer medical professionals, primarily based in the North America, to improve the diagnosis, treatment, and overall healthcare experience for patients in remote clinics.

This RFP invites proposals for the design, development, and deployment of a digital healthcare consultation platform. This platform will enable health workers in isolated clinics to capture and submit patient cases for remote assessment by volunteer doctors, with a core goal of timely and actionable feedback. This service, beginning in Kenya and Tanzania, is anticipated to scale across multiple African and potentially Asian nations.

2. Project Vision and Scope

Vision

The project aims to connect rural health centers with qualified volunteer doctors through a mobile platform. Health workers, primarily nurses, will use an Android device with a preloaded application to submit cases for evaluation. Doctors will review these cases and provide recommendations, ensuring responses are timely, feasible, and locally applicable.

Scope of Services

The core functionalities of the platform will include:

- Case Capture and Transmission: Health workers will submit cases via structured forms with optional photo attachments.
- Remote Assessment: North America based doctors will assess cases and provide recommendations within 48 hours to ensure timely responses before patient discharge.
- Recommendation Viability: Recommendations will be adapted based on the resources and capabilities available at each clinic, with system data maintaining information on clinic resources.
- Optional Video Call Capability: Video call functionality may be offered as an option for more complex cases, facilitating real-time assessment between clinics and doctors.
- Tracking and Reporting: Monitoring of case turnaround times, recommendation feasibility, and overall system performance to support operational insights and enhance healthcare delivery.

3. Functional and Technical Requirements

Core Functional Requirements

- Multi-User Android App for Health Workers: Health workers will use low-cost Android devices dedicated to the platform. A single phone may be used by multiple users, with user authentication enabled.
- Web-Based Interface for Doctors: Volunteer doctors will access the platform via a secure web application.
- Data Capture and Case Submission: Patient cases will be recorded on pre-configured forms within the app, with options for attachments.
- Response Tracking and Notification: Critical cases must be flagged for urgent review, with a reassessment prompt if no response is provided within 48 hours.
- Video Call Functionality: Direct in-app video calls between clinics and doctors, with no video storage requirement.
- Case History and Patient Records: The system will provide health workers with access to patient history to support continuity of care. Automated recommendations based on previous cases will not be required.
- Non-Local Data Storage: Data will not be stored in the originating country but rather in a centralized secure location.

Additional Technical Considerations

- Unreliable Internet Connectivity: The system must account for intermittent internet access, ensuring that essential data can be transmitted once connectivity is restored.
- Authentication and Security: User authentication will be enforced for all users, including volunteer doctors and health workers.
- Data Retention and Privacy: No mandatory data retention period is required beyond case handling, and patient data privacy is a priority.
- Scalability: The system must support approximately 200 clinic locations per country and allow for expansion across other African and Asian regions.
- Platform Language: English will be the operating language for all system interfaces.

4. Project Timeline

The goal is to have the platform operational in Kenya and Tanzania within six months to enable “Reach Health” to begin negotiations with Ministries of Health in additional countries. This implementation timeline is essential to secure further adoption of the model and demonstrate its effectiveness.

5. Performance and Monitoring Requirements

The solution must include built-in tracking and reporting capabilities to monitor:

- Turnaround Time for Case Responses: Tracking response time per case, particularly for urgent cases.
- Recommendation Feasibility and Effectiveness: Ensuring that doctors’ recommendations are feasible within the local context and observing patient outcomes where possible.
- System Utilization and Efficiency: Reports on usage patterns, video call frequency, and other key metrics to support future improvements