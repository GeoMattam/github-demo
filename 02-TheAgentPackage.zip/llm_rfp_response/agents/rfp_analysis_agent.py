# agents/rfp_analysis_agent.py

from .agent_base import AgentBase

class RFPAnalysisAgent(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="RFPAnalysisAgent", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self, rfp_content=None):
        sys_msg = "Act as software architect in a service company that is analyzing RFP document from a potential client. RFP is attached."

        usr_msg = f"""
        I want you to analyze the following RFP

        Topic: 
        -------------------------------------------
        {rfp_content}

        I want you to use the following structured approach based on TOGAF in the initial analysis.

        Approach:
        1. Preliminary Analysis
        - Review the RFP document thoroughly to understand the client's business context, goals, and high-level requirements. Provide list of them.
        - Identify key stakeholders mentioned.
        - Perform a SWOT analysis of the proposed project to assess its viability and potential challenges
        2. Requirements Analysis
        - Categorize requirements into functional and non-functional (NFRs)
        - Map requirements to TOGAF's Architecture Domains: Business, Data, Application, and Technology
        - Identify any gaps or ambiguities in the requirements that need clarification.
        3. Architectural Vision
        - Develop a high-level architectural vision that aligns with the client's business goals
        - Consider innovative approaches that could provide additional value to the client3.
        4. Stakeholder Management
        - Analyze stakeholder interests and concerns as outlined in the RFP.
        Prepare tailored communication strategies for different stakeholder groups6.
        Plan for continuous stakeholder engagement throughout the proposal process6.
        5. Risk Assessment
        Identify potential risks associated with the project requirements6.
        - Develop mitigation strategies for identified risks.
        - Highlight how the proposed architecture addresses key client concerns
        6. Technology Evaluation
        - Assess the client's current technology landscape if provided in the RFP.
        - Evaluate potential technologies and frameworks that could meet the project requirements4.
        Consider scalability, integration capabilities, and long-term viability of proposed technologies.
        7. Compliance and Standards
        - Review any compliance requirements or industry standards mentioned in the RFP.
        - Ensure the proposed architecture adheres to relevant regulations (e.g., data protection laws).
        8. Cost and Resource Estimation
        - Develop high-level estimates for implementation costs and required resources.
        - Consider total cost of ownership, including ongoing maintenance and support.
        9. Team and Timeline
        - Create the anticipated development team to work on the project, roles and count.
        - Develop potential timeline with high-level estimations.

        
        """

        usr_msg += """
        Final RFP Analysis Output:
        -------------------------------------------

        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]
        
        response = self.call_model(messages, max_tokens=130000)

        return response
