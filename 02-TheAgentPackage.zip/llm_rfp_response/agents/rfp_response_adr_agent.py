# agents/rfp_response_adr_agent.py

from .agent_base import AgentBase

class RFPResponseADRAgent(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="RFPResponseADRAgent", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self, rfp_response=None):
        sys_msg = "Act as software architect in a service company that is creating Architectural Decision Records (ADRs) based on response to RFP. The response to RFP is attached."

        usr_msg = f"""
        Create ADRs based on the response created for the RFP.

        RFP Response: 
        -------------------------------------------
        {rfp_response}
        
        Use the following format:

        # Title

        ## Date

        ## Status
        What is the status, such as proposed, accepted, rejected, deprecated, superseded, etc.?

        ## Context
        What is the issue that we're seeing that is motivating this decision or change?

        ## Decision
        What is the change that we're proposing and/or doing?

        ## Consequences
        What becomes easier or more difficult to do because of this change?

        """

        usr_msg += """
        ADR Response Output:
        -------------------------------------------

        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]
        
        response = self.call_model(messages, max_tokens=130000)

        return response
