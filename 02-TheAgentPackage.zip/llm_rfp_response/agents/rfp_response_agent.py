# agents/rfp_analysis_agent.py

from .agent_base import AgentBase

class RFPResponseAgent(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="RFPResponseAgent", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self, rfp_initial_analysis=None):
        sys_msg = "Act as software architect in a service company that is responding to RFP document from a potential client based on inital analysis. RFP initial analysis is attached."

        usr_msg = f"""
        Based on the below analysis provided create a response to the RFP that follows the following format:

        Analysis: 
        -------------------------------------------
        {rfp_initial_analysis}
        
        1. Executive summary
        2. Deliverables and project summary
        3. Technical solution

        For (2) include team structure and timeline.

        For (3) take care of the following:
        - Design the system architecture and identify technologies
        - Define the infrastructure
        - Outline security strategies
        - Describe the testing and quality assurance approach
        - Address regulative aspects if required

        """

        usr_msg += """
        Final RFP Response Output:
        -------------------------------------------

        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]
        
        response = self.call_model(messages, max_tokens=130000)

        return response
