# agents/__init__.py

from .rfp_analysis_agent import RFPAnalysisAgent
from .rfp_response_agent import RFPResponseAgent

class RFPResponseAgentManager:
    def __init__(self, max_retries=2, verbose=True):
        self.agents = {
            "analyze_rfp": RFPAnalysisAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "respond_to_rfp": RFPResponseAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
        }

    def get_agent(self, agent_name):
        agent = self.agents.get(agent_name)
        if not agent:
            raise ValueError(f"Agent '{agent_name}' not found.")
        return agent