import os
from io import StringIO

from agents import RFPResponseAgentManager
from utils.logger import logger

from dotenv import load_dotenv

import streamlit as st

def main(agent_manager):
    logger.info("Autonomous Agents for RFP Response...")
    rfp_content = None
    initial_analysis = None
    rfp_response = None
    
    st.set_page_config(
        layout="wide",
        page_title = "Autonomous Agents for RFP Response"
    )

    st.title("Analyse and Respond to RFP using Autonomous Agents")
    uploaded_file = st.file_uploader("Upload a RFP file", type=["md"])

    with st.expander("Original RFP Sample Uploaded"):
        if uploaded_file is not None:
            # Save the uploaded file to disk
            stringio = StringIO(uploaded_file.getvalue().decode("utf-8"))

            # To read file as string:
            rfp_content = stringio.read()
            st.success("Your Uploaded RFP file: " + "\n" + rfp_content)

    col1, col2 = st.columns(2)

    with col1:
        if uploaded_file is not None:
            # Save the uploaded file to disk
            stringio = StringIO(uploaded_file.getvalue().decode("utf-8"))

            # To read file as string:
            rfp_content = stringio.read()

            if st.button("Analyze RFP"):
                # call the agent to analyze the rfp and generate initial analysis
                rfp_analyze_agent = agent_manager.get_agent("analyze_rfp")
                with st.spinner("Analyzing Uploaded RFP..."):
                    try:
                        initial_analysis = rfp_analyze_agent.execute(rfp_content=rfp_content)
                        st.subheader("Initial Analysis:")
                        st.write(initial_analysis)
                    except Exception as e:
                        st.error(f"Error: {e}")
                        logger.error(f"RFPAnalysisAgent Error: {e}")
                        return
                    
                with col2:
                    # call the agent to respond to the RFP based on the initial analysis of the RFP shared
                    rfp_responder_agent = agent_manager.get_agent("respond_to_rfp")
                    with st.spinner("Creating response based on Initial Analysis of RFP..."):
                        try:
                            rfp_response = rfp_responder_agent.execute(rfp_initial_analysis=initial_analysis)
                            st.subheader("RFP Response:")
                            st.write(rfp_response)
                        except Exception as e:
                            st.error(f"Error: {e}")
                            logger.error(f"RFPResponseAgent Error: {e}")
                            return

if __name__ == "__main__":
    agent_manager = RFPResponseAgentManager(max_retries=2, verbose=True)
    main(agent_manager)
