from agents import AgentManager
from utils.logger import logger
import os
from dotenv import load_dotenv

load_dotenv()

def main():
    text = """
    Tonsillitis is inflammation of the tonsils in the upper part of the throat. It can be acute or chronic.[8][9][2] 
    Acute tonsillitis typically has a rapid onset.[10] Symptoms may include sore throat, fever, enlargement of the 
    tonsils, trouble swallowing, and enlarged lymph nodes around the neck.[1][2] Complications include peritonsillar 
    abscess (quinsy).[1][3]

    Tonsillitis is most commonly caused by a viral infection and about 5% to 40% of cases are caused by a bacterial 
    infection.[1][5][6] When caused by the bacterium group A streptococcus, it is classed as streptococcal 
    tonsillitis[11] also referred to as strep throat.[12] Rarely bacteria such as Neisseria gonorrhoeae, 
    Corynebacterium diphtheriae, or Haemophilus influenzae may be the cause.[5] Typically the infection is spread 
    between people through the air.[6] A scoring system, such as the Centor score, may help separate possible 
    causes.[1][5] Confirmation may be by a throat swab or rapid strep test.[1][5]

    Treatment efforts involve improving symptoms and decreasing complications.[5] Paracetamol (acetaminophen) and 
    ibuprofen may be used to help with pain.[1][5] If strep throat is present the antibiotic penicillin by mouth is 
    generally recommended.[1][5] In those who are allergic to penicillin, cephalosporins or macrolides may be 
    used.[1][5] In children with frequent episodes of tonsillitis, tonsillectomy modestly decreases the risk of 
    future episodes.[13]

    About 7.5% of people have a sore throat in any three-month period and 2% of people visit a doctor for 
    tonsillitis each year.[7] It is most common in school-aged children and typically occurs in the colder months 
    of autumn and winter.[5][6] The majority of people recover with or without medication.[1][5] In 82% of people, 
    symptoms resolve within one week, regardless if bacteria or viruses were present.[4] Antibiotics probably 
    reduce the number of people experiencing sore throat or headache, but the balance between modest symptom
    reduction and the potential hazards of antimicrobial resistance must be recognised.[4]
    """

    agent_manager = AgentManager(max_retries=2, verbose=True)
    logger.info("Summarize Medical Text")
    main_agent = agent_manager.get_agent("summarize")
    validator_agent = agent_manager.get_agent("summarize_validator")
    summary = main_agent.execute(text)
    logger.info(summary)

if __name__ == "__main__":
    main()