from .agent_base import AgentBase

"""
You are a top tier software developer skilled at docomenting and explaining code.
You have been asked to document code in a project named {project_name}.

You are not to return the code itself, but rather a detailed explanation of the code.

The file layout is as follows:
{document_tree}

{function_block}

The file you must document is: {file_name}

Make sure to include explanations for all functions, classes, and key logic in the file.
Do not wrap the output in a code block.  Do not start your document with a heading; one will automatically be added.

{file_name} Contents:
----------------------------------------
{file_contents}
"""
class CodeDocumentationTool(AgentBase):
    def __init__(self, model, max_retries, verbose=True):
        super().__init__(name="CodeDocumentationTool", model=model, max_retries=max_retries, verbose=verbose)
    
    def execute(self, file_contents):
        sys_msg = """You are a top tier software developer skilled at docomenting and explaining code."""
        usr_msg = f"""
        You have been asked to document COBOL code.

        You are not to return the code itself, but rather a detailed explanation of the code.

        The code you must document is provided below between triple backticks

        Make sure to include explanations for all functions, classes, and key logic in the file.
        Do not wrap the output in a code block.  Do not start your document with a heading; one will automatically be added.

        Contents:
        ----------------------------------------
        ```{file_contents}```
        """

        messages = [
            { "role": "system", "content": sys_msg },
            { "role": "user", "content": usr_msg } 
        ]
        summary = self.call_model(messages, max_tokens=300)
        return summary