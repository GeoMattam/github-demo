from .summarize_tool import SummarizeTool
from .summary_validator_agent import SummarizeValidatorAgent
from .code_documentation_tool import CodeDocumentationTool

class AgentManager:
    def __init__(self, max_retries=2, verbose=True):
        self.agents = {
            "summarize": SummarizeTool(model="llama3.2", max_retries=max_retries, verbose=verbose),
            "summarize_validator": SummarizeValidatorAgent(model="llama3.2", max_retries=max_retries, verbose=verbose),
            "code_documentation": CodeDocumentationTool(model="qwen2.5", max_retries=max_retries, verbose=verbose)
        }
    
    def get_agent(self, agent_name):
        agent = self.agents.get(agent_name)
        if not agent:
            raise ValueError(f"Agent '{agent_name} not found")
        return agent