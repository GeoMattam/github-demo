from openai import OpenAI
from abc import ABC, abstractmethod
from loguru import logger
import os
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"), base_url="http://localhost:11434/v1")

class AgentBase(ABC):
    def __init__(self, name, model, max_retries=2, verbose=True):
        self.name = name
        self.model = model
        self.max_retries = max_retries
        self.verbose = verbose
    
    @abstractmethod
    def execute(self, *args, **kwargs):
        pass

    def call_model(self, messages, temperature=0.7, max_tokens=150):
        retries = 0
        while retries < self.max_retries:
            try:
                if self.verbose:
                    logger.info(f"[{self.name}] Sending message to OpenAI")
                    for msg in messages:
                        logger.debug(f" {msg['role']}: {msg['content']}")
                
                response = client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens
                )
                reply = response.choices[0].message
                if self.verbose:
                    logger.info(f"[{self.name} Recieved Response: {reply}]")
                return reply
            except Exception as e:
                retries += 1
                logger.error(f"[{self.name}] Error during OpenAI call: {e}. Retry {retries}/{self.max_retries}")
        
        raise Exception(f"[{self.name}] Failed to get response from OpenAI after {self.max_retries} retires.")
        