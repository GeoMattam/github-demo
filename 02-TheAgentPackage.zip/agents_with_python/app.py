import streamlit as st
from agents import AgentManager
from utils.logger import logger
import os
from dotenv import load_dotenv

load_dotenv()

def code_documentation_section(agent_manager):
    st.header("Document COBOL Code")
    text = st.text_area("Enter the code to document:", height=200)
    if st.button("Document Code"):
        if text:
            main_agent = agent_manager.get_agent("code_documentation")
            logger.info("Agent Instantiated...")
            with st.spinner("Documenting Code..."):
                try:
                    documentation = main_agent.execute(text)
                    st.subheader("Code Documentation:")
                    st.write(documentation)
                except Exception as e:
                    st.error(f"Error: {e}")
                    logger.error(f"CodeDocumentationAgent Error: {e}")
                    return
        else:
            st.warning("Please enter the COBOL code to document.")

def write_and_refine_article_section(agent_manager):
    pass

def summarize_section(agent_manager):
    pass

def main():
    st.set_page_config(page_title="Multi Agent AI System", layout="wide")
    st.title("Multi Agent AI System with Collaboration and validation")

    st.sidebar.title("Select Task")

    task = st.sidebar.selectbox(
        "choose a task:",
        ("Document COBOL Code","Write and Refine Article","Summarize Text")
    )

    agent_manager = AgentManager(max_retries=2, verbose=True)

    if task == "Document COBOL Code":
        code_documentation_section(agent_manager)
    elif task == "Write and Refine Article":
        write_and_refine_article_section(agent_manager)
    elif task == "Summarize Text":
        summarize_section(agent_manager)

if __name__ == "__main__":
    main()