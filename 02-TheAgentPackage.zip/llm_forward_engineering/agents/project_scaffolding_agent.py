# agents/write_article_agent.py

from .agent_base import AgentBase

"""
We will try focussing on scaffolding for Java projects, specifically for creating production-ready microservices. This means from the 
start including aspects like observability, security, data integrations, API design, and more (see prompt below for all requirements).

The idea is that LLMs can provide a way to use natural language (not bound to some specific Domain Specific Language [DSL]) and in very 
general description (without much detailed specification) to quickly get a service with already built-in support for common scenarios and 
implemented with the latests versions and standards. Nice challenge !!!!

The prompt outlines the relevant aspects of a modern (micro)service while remaining intentionally vague

This allows LLMs to make choices, ideally using current best practices and standard up-to-date libraries. A more detailed prompt might 
work better but would force specific libraries or approaches but would require significant effort to construct and maintain, essentially 
defeating the purpose of scaffolding by coming too close to writing the service from scratch. The final expectation is for LLMs to deliver 
code in a form that compiles and runs.
"""
class ProjectScaffoldingTool(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="ProjectScaffoldingTool", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self, deliverables=None):
        sys_msg = "You will act as a software developer."

        usr_msg = f"""
        I need to design a modern Java-based service with the following requirements and best practices.

        1. Project Structure
        * Follow a clean and maintainable project structure with meaningful package names.
        * Include directories for config, controller, service, repository, model, exception, util, and whatever is needed.
        * Organize the project using Maven.
        * Use Spring as the main framework.

        2. Integrations
        * Database integration with PostgreSQL
        * Database migrations via Liquibase.
        * Async communication downstream via Kafka
        * Caching via Redis
        * Logging: SLF4J and Logback with structured JSON logging.

        3. Observability
        * Implement structured logging with MDC for tracking request IDs.
        * Collect metrics using Micrometer and integrate with Prometheus.
        * Provide health and readiness endpoints using Spring Boot Actuator.

        4. Testing
        * Unit tests for individual components (e.g., service, utility).
        * Integration tests using Testcontainers

        5. API Design
        * Follow RESTful principles for API design.
        * Security support for JWT and OAuth2.0.
        * Use DTOs to separate API models from domain models.

        6. Deployment
        *  Dockerfile to containerize the application.

        """

        if deliverables:
            usr_msg += f"""
            Deliverables: 
            -------------------------------------------
            {deliverables}

            """

        usr_msg += """
        Final Output:
        -------------------------------------------

        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]
        
        response = self.call_model(messages, max_tokens=130000)

        return response

"""
* A sample project structure with package hierarchy.
    * Use com.myservice as root level package
* All examples should work with Sample entity that has a number of characteristic fields, but must include: ID, time created, time updated, active flag.
* Example code snippets for all layer (controllers, services, integrations…).
* A configuration for logging, tracing, and metrics collection.
* Examples for observability and logging
* Provide a sample REST controller with CRUD endpoints.
* Example test cases demonstrating the testing strategy.
* A Dockerfile YAML file
* Examples for database migration
* Generated API documentation using OpenAPI/Swagger.
* Comprehensive Readme.md file with guidelines how to work with code, run tests, deploy, etc.
"""