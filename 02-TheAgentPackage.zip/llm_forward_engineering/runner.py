from agents import AgentManager
from utils.logger import logger

import os
from dotenv import load_dotenv

import streamlit as st

# Load environment variables from .env if present
load_dotenv()

def project_scaffolding_section(agent_manager):
    logger.info(f"Generating Project Scaffolding using AI Agent...")
    st.header("Generate Project Scaffolding")
    text = st.text_area("Enter the deliverables:", height=200)
    if st.button("Generate"):
        if text:
            logger.info(f"Generating Project Scaffolding...")
            main_agent = agent_manager.get_agent("scaffolding")
            with st.spinner("Generating Project Scaffolding..."):
                try:
                    details = main_agent.execute(deliverables=text)
                    st.subheader("Generated Project Scaffolding:")
                    st.write(details)
                except Exception as e:
                    st.error(f"Error: {e}")
                    logger.error(f"MetaPromptGeneratorTool Error: {e}")
                    return
        else:
            st.warning("Please enter the intent to generate prompt.")

def main():
    st.set_page_config(page_title="Forward Engineering AI Agents System", layout="wide")
    st.title("Forward Engineering AI Agents System with Collaboration")

    st.sidebar.title("Select Task")
    task = st.sidebar.selectbox("Choose a task:", [
        "Project Scaffolding"
    ])

    agent_manager = AgentManager(max_retries=2, verbose=True)
    if task == "Project Scaffolding":
        project_scaffolding_section(agent_manager)

if __name__ == "__main__":
    main()