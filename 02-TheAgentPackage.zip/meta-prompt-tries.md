### TRY 1
**prompt**
Goal: Generate a prompt that instructs an LLM to analyze a COBOL file and extract its business logic 
while converting the procedural code into structured pseudo-code.
Prompt Requirements:
Ensure the LLM parses and understands COBOL syntax, including:
DIVISION structures (IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE)
PERFORM statements, conditionals (IF, EVALUATE), loops (PERFORM UNTIL)
File I/O operations (OPEN, READ, WRITE, CLOSE)
Data transformations and computations
Guide the LLM to extract and summarize business logic, preserving intent while removing COBOL-specific syntax.
Require the LLM to generate structured pseudo-code in a modern, readable format (e.g., Python-like or structured English).
Specify that the output should be modular, mapping COBOL paragraphs and sections to logical functions.
Include an option to export the extracted business logic and pseudo-code in Markdown.
Emphasize clarity, accuracy, and maintainability to assist in modernizing legacy COBOL applications.

### TRY 1
**prompt**
**to generate psuedocode alone**
**Objective:**
        Analyze a given COBOL source code in the input below between triple backticks, extract key business logic, and generate clear, structured pseudo-code while preserving the 
        logical flow and intent.

        **Instructions:**
        1. Parse & Understand COBOL Structure:
            - Identify DIVISION sections (IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE).
            - Extract variable declarations and file structures.
            - Recognize paragraphs, sections, and control flow.
        2. Extract Business Logic:
            - Identify conditional statements (IF, EVALUATE, etc.) and translate them into structured logic.
            - Capture loop constructs (PERFORM, GO TO, etc.) and rewrite them in structured form.
            - Extract data manipulations (MOVE, COMPUTE, STRING, UNSTRING, etc.).
        3. Generate Pseudo-Code:
            - Use a structured, human-readable format similar to Python or structured English.
            - Maintain indentation and hierarchy for clarity.
            - Replace COBOL-specific syntax with intuitive language-neutral terms.
            - Clearly label business rules and computations.
        4. Ensure Readability & Accuracy:
            - Remove unnecessary COBOL syntax while preserving meaning.
            - Format output in consistent indentation.
            - If needed, provide comments explaining complex logic.

        **Input**
        ```{code}```
    
    system: "You are a senior mainframe developer skilled at COBOL and in documenting and explaining code."

""" with open("./mainframe_code/LTCAL042", "r", encoding="utf-8") as file:
file_contents = file.read() """
