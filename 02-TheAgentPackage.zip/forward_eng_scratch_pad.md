# Project Scaffolding
**Deliverables**
* A sample project structure with package hierarchy.
    * Use com.myservice as root level package
* All examples should work with Sample entity that has a number of characteristic fields, but must include: ID, time created, time updated, active flag.
* Example code snippets for all layer (controllers, services, integrations…).
* A configuration for logging, tracing, and metrics collection.
* Examples for observability and logging
* Provide a sample REST controller with CRUD endpoints.
* Example test cases demonstrating the testing strategy.
* A Dockerfile YAML file
* Examples for database migration
* Generated API documentation using OpenAPI/Swagger.
* Comprehensive Readme.md file with guidelines how to work with code, run tests, deploy, etc.

