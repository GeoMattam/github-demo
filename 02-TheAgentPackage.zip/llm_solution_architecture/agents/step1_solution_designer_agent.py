# agents/step1_solution_designer_agent.py

from .agent_base import AgentBase

"""
Solution Architect Agent
Focus: Holistic design and integration
Agent’s Role: The Solution Architect agent is the starter among the other agents, ensuring that the design of the solution 
aligns with both the business objectives and technical requirements. This agent creates a cohesive, efficient, and effective 
architecture that serves the overarching goals of the project.

NAR: COMMENT SECTION - WIP
------------------------------------------------------------------------------------------------------------------------------
2025-03-08 > 18:45
Created the agent class with the scaffolding code
2025-03-08 > 18:45
Need to decide on the inputs that this agent will take via the execute function and build out the appropriate system and user
messages to execute the agent. Do we need the outputs in pydantic format???
------------------------------------------------------------------------------------------------------------------------------

"""
class SolutionDesignerAgent(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="SolutionDesignerAgent", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self):
        sys_msg = "[Appropriate message has to be crafted]"

        usr_msg = f"""
        [Appropriate message has to be crafted]
        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]
        
        response = self.call_model(messages, max_tokens=130000)

        return response
