# agents/__init__.py

from .step1_solution_designer_agent import SolutionDesignerAgent
from .step2_operational_excellence_agent import OperationalExcellenceAgent
from .step3_security_agent import SecurityAgent
from .step4_reliability_agent import ReliabilityAgent
from .step5_performance_efficiency_agent import PerformanceEfficiencyAgent
from .step6_cost_optimization_agent import CostOptimizationAgent
from .step7_sustainability_agent import SustainabilityAgent
from .step8_solution_evaluator_agent import SolutionEvaluatorAgent

class AISolutionArchitectAgentManager:
    def __init__(self, max_retries=2, verbose=True):
        self.agents = {
            "solution_designer": SolutionDesignerAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "operational_excellence": OperationalExcellenceAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "security": SecurityAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "reliability": ReliabilityAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "performance_efficiency": PerformanceEfficiencyAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "cost_optimization": CostOptimizationAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "sustainability": SustainabilityAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "solution_evaluator": SolutionEvaluatorAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
        }

    def get_agent(self, agent_name):
        agent = self.agents.get(agent_name)
        if not agent:
            raise ValueError(f"Agent '{agent_name}' not found.")
        return agent