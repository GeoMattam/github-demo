# agents/step3_security_agent.py

from .agent_base import AgentBase

"""
Security Agent
Focus: Threat detection, risk assessment, and compliance
Agent’s Role: Applies stringent security protocols to protect data and operations against cyber threats.

NAR: COMMENT SECTION - WIP
------------------------------------------------------------------------------------------------------------------------------
2025-03-08 > 18:50
Created the agent class with the scaffolding code
2025-03-08 > 18:50
Need to decide on the inputs that this agent will take via the execute function and build out the appropriate system and user
messages to execute the agent. Do we need the outputs in pydantic format???
------------------------------------------------------------------------------------------------------------------------------

"""
class SecurityAgent(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="SecurityAgent", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self):
        sys_msg = "[Appropriate message has to be crafted]"

        usr_msg = f"""
        [Appropriate message has to be crafted]
        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]
        
        response = self.call_model(messages, max_tokens=130000)

        return response
