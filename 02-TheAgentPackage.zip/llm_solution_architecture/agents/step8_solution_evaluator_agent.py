# agents/step8_solution_evaluator_agent.py

from .agent_base import AgentBase

"""
Solution Evaluator Agent
Focus: Comprehensive assessment and scoring
Agent’s Role: The Solution Evaluator agent acts as the final reviewer and scorer of the architecture. After the speciality-focused 
agents provide their assessments and the Solution Architect integrates these into a unified design, the Solution Evaluator analyzes 
the effectiveness of the entire solution against predefined criteria. This includes comparing the actual architecture to an ideal 
condition where all focusses areas are rated as excellent, thus providing a clear metric to gauge the solution’s success.

NAR: COMMENT SECTION - WIP
------------------------------------------------------------------------------------------------------------------------------
2025-03-08 > 18:55
Created the agent class with the scaffolding code
2025-03-08 > 18:55
Need to decide on the inputs that this agent will take via the execute function and build out the appropriate system and user
messages to execute the agent. Do we need the outputs in pydantic format???
------------------------------------------------------------------------------------------------------------------------------

"""
class SolutionEvaluatorAgent(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="SolutionEvaluatorAgent", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self):
        sys_msg = "[Appropriate message has to be crafted]"

        usr_msg = f"""
        [Appropriate message has to be crafted]
        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]
        
        response = self.call_model(messages, max_tokens=130000)

        return response
