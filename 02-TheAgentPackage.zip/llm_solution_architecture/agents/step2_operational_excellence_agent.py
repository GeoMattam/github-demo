# agents/step2_operational_excellence_agent.py

from .agent_base import AgentBase

"""
Operational Excellence Agent
Focus: Automation, monitoring, and iterative improvement
Agent’s Role: Ensures that processes are in place to keep the cloud environment agile and adaptable to changes.

NAR: COMMENT SECTION - WIP
------------------------------------------------------------------------------------------------------------------------------
2025-03-08 > 18:47
Created the agent class with the scaffolding code
2025-03-08 > 18:47
Need to decide on the inputs that this agent will take via the execute function and build out the appropriate system and user
messages to execute the agent. Do we need the outputs in pydantic format???
------------------------------------------------------------------------------------------------------------------------------

"""
class OperationalExcellenceAgent(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="OperationalExcellenceAgent", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self):
        sys_msg = "[Appropriate message has to be crafted]"

        usr_msg = f"""
        [Appropriate message has to be crafted]
        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]
        
        response = self.call_model(messages, max_tokens=130000)

        return response
