# agents/step6_cost_optimization_agent.py

from .agent_base import AgentBase

"""
Cost Optimization Agent
Focus: Cost-effective resource deployment and maintenance
Agent’s Role: Identifies savings opportunities and promotes the most economical use of cloud resources.

NAR: COMMENT SECTION - WIP
------------------------------------------------------------------------------------------------------------------------------
2025-03-08 > 18:50
Created the agent class with the scaffolding code
2025-03-08 > 18:50
Need to decide on the inputs that this agent will take via the execute function and build out the appropriate system and user
messages to execute the agent. Do we need the outputs in pydantic format???
------------------------------------------------------------------------------------------------------------------------------

"""
class CostOptimizationAgent(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="CostOptimizationAgent", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self):
        sys_msg = "[Appropriate message has to be crafted]"

        usr_msg = f"""
        [Appropriate message has to be crafted]
        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]
        
        response = self.call_model(messages, max_tokens=130000)

        return response
