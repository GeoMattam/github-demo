import os

from agents import AISolutionArchitectAgentManager
from utils.logger import logger

from dotenv import load_dotenv

import streamlit as st

def main():
    logger.info("Autonomous Agents for Cloud Architecture...")

if __name__ == "__main__":
    main()
