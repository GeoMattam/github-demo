# ------------------------------------------------------------------------------------
# Customer Support Ticket Classification System
# You can classify almost any data at this point using the techniques shown below
# You can classify text, images, audio etc
# ------------------------------------------------------------------------------------
import os
import logging

import instructor
from pydantic import BaseModel, Field
from openai import OpenAI
from enum import Enum
from typing import List

PROVIDER = "google"
client = None
model = None

# get the current file name
log = os.path.basename(__file__) + ".log"

# Set up logging configuration
logging.basicConfig(
    # filename=log,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

if PROVIDER.upper()=="ollama".upper():
    client = OpenAI(base_url="http://localhost:11434/v1", api_key=os.getenv("OLLAMA_API_KEY"))
    model = "llama3.2"
elif PROVIDER.upper()=="google".upper():
    # use the below mentioned client and model if you want to run against closed model gemini-1.5-flash
    client = OpenAI(base_url="https://generativelanguage.googleapis.com/v1beta/openai/", api_key=os.getenv("GOOGLE_API_KEY"))
    model = "gemini-1.5-flash"

logger.info(f"Instantiated the model for the Customer Support Ticket Classification System: [{model}]")

# Sample customer support tickets
ticket1 = """
I ordered a laptop from your store last week (Order #12345), but I received a tablet instead. 
This is unacceptable! I need the laptop for work urgently. Please resolve this immediately or I'll have to dispute the charge.
"""

ticket2 = """
Hello, I'm having trouble logging into my account. I've tried resetting my password, but I'm not receiving the reset email. 
Can you please help me regain access to my account? I've been a loyal customer for years and have several pending orders.
"""

# ------------------------------------------------------------------------------------
# Regular completion using OpenAI (using drawbacks)
# This from a system design perspective is not ideal because we just ask it to classify the ticket into a category
# we have no idea what all the potential categories could be. We also see that it return a response which is verbose and 
# textual along with justification. This can be improved with better prompt and prompting techniques but still it would
# require some parsing to get the category alone. This will also change if for example we change the temperature
# Drawbacks of this approach:
# 1. No structured output, making it difficult to integrate into automated systems
# 2. No validation of the output, potentially leading to inconsistent categorizations
# 3. Limited information extracted, missing important details for prioritization
# 4. No confidence score, making it hard to flag uncertain classifications for human review
# ------------------------------------------------------------------------------------
def classify_ticket_simple(ticket_text: str) -> str:    
    response = client.chat.completions.create(
        model=model,
        temperature=0,
        messages=[
            {
                "role": "system",
                "content": "Classify the following customer support ticket into a category.",
            },
            {"role": "user", "content": ticket_text},
        ]
    )
    return response.choices[0].message.content

""" # uncomment the below lines finally
result = classify_ticket_simple(ticket1)
print(result) """

# --------------------------------------------------------------
# Step 1: Get clear on the objectives
# --------------------------------------------------------------

"""
Objective: Develop an AI-powered ticket classification system that:
- Accurately categorizes customer support tickets
- Assesses the urgency and sentiment of each ticket
- Extracts key information for quick resolution
- Provides confidence scores to flag uncertain cases for human review
Business impact:
- Reduce average response time by routing tickets to the right department
- Improve customer satisfaction by prioritizing urgent and negative sentiment tickets
- Increase efficiency by providing agents with key information upfront
- Optimize workforce allocation by automating routine classifications
"""

# --------------------------------------------------------------
# Step 2: Patch your LLM with instructor
# --------------------------------------------------------------

# Instructor makes it easy to get structured data like JSON from LLMs - you can install with a simple pip install -U instructor
# This is a secret weapon to build reliable large language model applications that can make it to production
# We are going to use data models and specifically pydantic

# instructor makes it easy to get structured data like JSON from llm. We understand the objectives first and also put in validation using
# the instructor library to really ensure our system is robust
# now we have a client which is instructor ready and we can provide it with response models
# client = instructor.patch(OpenAI(base_url="http://localhost:11434/v1", api_key=os.getenv("OLLAMA_API_KEY")))
""" client = instructor.patch(OpenAI(base_url="https://generativelanguage.googleapis.com/v1beta/openai/", api_key=os.getenv("GOOGLE_API_KEY")))
model = "gemini-1.5-flash" """

if PROVIDER.upper()=="ollama".upper():
    client = OpenAI(base_url="http://localhost:11434/v1", api_key=os.getenv("OLLAMA_API_KEY"))
    model = "llama3.2"
elif PROVIDER.upper()=="google".upper():
    # use the below mentioned client and model if you want to run against closed model gemini-1.5-flash
    client = OpenAI(base_url="https://generativelanguage.googleapis.com/v1beta/openai/", api_key=os.getenv("GOOGLE_API_KEY"))
    model = "gemini-1.5-flash"

# --------------------------------------------------------------
# Step 3: Define Pydantic data models
# --------------------------------------------------------------

"""
This code defines a structured data model for classifying customer support tickets using Pydantic and Python's Enum class. 
It specifies categories, urgency levels, customer sentiments, and other relevant information as predefined options or constrained fields. 
This structure ensures data consistency, enables automatic validation, and facilitates easy integration with AI models and other parts of a support ticket system.
"""

class TicketCategory(str, Enum):
    ORDER_ISSUE = "order_issue"
    ACCOUNT_ACCESS = "account_access"
    PRODUCT_INQUIRY = "product_inquiry"
    TECHNICAL_SUPPORT = "technical_support"
    BILLING = "billing"
    OTHER = "other"

class CustomerSentiment(str, Enum):
    ANGRY = "angry"
    FRUSTRATED = "frustrated"
    NEUTRAL = "neutral"
    SATISFIED = "satisfied"

class TicketUrgency(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class TicketClassification(BaseModel):
    category: TicketCategory
    urgency: TicketUrgency
    sentiment: CustomerSentiment
    confidence: float = Field(ge=0, le=1, description="Confidence score for the classification")
    key_information: List[str] = Field(description="List of key points extracted from the ticket")
    suggested_action: str = Field(description="Brief suggestion for handling the ticket")

# let us see how that looks like when we create an object
ticket_classification = TicketClassification(
    category=TicketCategory.ORDER_ISSUE,
    urgency=TicketUrgency.HIGH,
    sentiment=CustomerSentiment.ANGRY,
    confidence=0.9,
    key_information=["Order #12345", "Received tablet instead of laptop"],
    suggested_action="Contact customer to arrange laptop delivery",
)
print(ticket_classification)

# --------------------------------------------------------------
# Step 4: Define Pydantic data models
# --------------------------------------------------------------

"""
Next step is to take this powerful feature of pydantic and combine those with the powerful features of the large language models.
That is where the instructor library is going to come in because instructor allows us to very easily do this

In step 4 we bring everything together in a single function. It is almost the same as the classify_ticket_simple function but with
subtle differences. Since we have patched the client with instructor we can now put in a 'response_model' that accepts a pydantic data model.
We can now tell the llm model that we want to receive a TicketClassification data model from our system. So now instead of getting a chat
completion back from the model we get the TicketClassification response model back from the llm and in doing do we immediately put the validation
in place. The good thing about pydantic is the validation errors that are produced are in natural language and very easy for humans to understand.
This allows us to use that as a feedback for the llm to iterate on that using 'max_retries' parameter which will feed the error along with the
original content and self correct. This helps to create pretty robust systems
"""

def classify_ticket(ticket_text: str) -> TicketClassification:
    """ response = client.chat.completions.create(
        model=model,
        response_model=TicketClassification,
        temperature=0,
        max_retries=3,
        messages=[
            {
                "role": "system",
                "content": "Analyze the following customer support ticket and extract the requested information."
            },
            {"role": "user", "content": ticket_text}
        ]
    )
    return response """
    completion = client.beta.chat.completions.parse(
        model=model,
        temperature=0,
        messages=[
            {
                "role": "system",
                "content": "Analyze the following customer support ticket and extract the requested information."
            },
            {"role": "user", "content": ticket_text}
        ],
        response_format=TicketClassification,
    )
    result = completion.choices[0].message.parsed
    return result

result1 = classify_ticket(ticket1)
result2 = classify_ticket(ticket2)

print(result1.model_dump_json(indent=2))
print(result2.model_dump_json(indent=2))

# --------------------------------------------------------------
# Step 5: Optimize your prompts and experiment
# --------------------------------------------------------------
# To optimize:
# 1. Refine the system message to provide more context about your business
# 2. Experiment with different models (e.g., gpt-3.5-turbo vs gpt-4, gemini, llama3.2, mistral)
# 3. Fine-tune the model on your specific ticket data if available [this is something to think about]
# 4. Adjust the TicketClassification model based on business needs

sys_msg = """
You are an AI assistant for a large e-commerce platform's customer support team. 
Your role is to analyze incoming customer support tickets and provide structured information to help our team respond quickly and effectively.
Business Context:
- We handle thousands of tickets daily across various categories (orders, accounts, products, technical issues, billing).
- Quick and accurate classification is crucial for customer satisfaction and operational efficiency.
- We prioritize based on urgency and customer sentiment.
Your tasks:
1. Categorize the ticket into the most appropriate category.
2. Assess the urgency of the issue (low, medium, high, critical).
3. Determine the customer's sentiment.
4. Extract key information that would be helpful for our support team.
5. Suggest an initial action for handling the ticket.
6. Provide a confidence score for your classification.
Remember:
- Be objective and base your analysis solely on the information provided in the ticket.
- If you're unsure about any aspect, reflect that in your confidence score.
- For 'key_information', extract specific details like order numbers, product names, or account issues.
- The 'suggested_action' should be a brief, actionable step for our support team.
Analyze the following customer support ticket and provide the requested information in the specified format.
"""

def classify_ticket(ticket_text: str) -> TicketClassification:
    completion = client.beta.chat.completions.parse(
        model=model,
        temperature=0,
        messages=[
            {
                "role": "system",
                "content": sys_msg,
            },
            {"role": "user", "content": ticket_text}
        ],
        response_format=TicketClassification,
    )
    result = completion.choices[0].message.parsed
    return result

result1 = classify_ticket(ticket1)
result2 = classify_ticket(ticket2)

print(result1.model_dump_json(indent=2))
print(result2.model_dump_json(indent=2))