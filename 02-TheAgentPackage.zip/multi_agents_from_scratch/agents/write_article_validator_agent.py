# agents/write_article_validator_agent.py

from .agent_base import AgentBase

class WriteArticleValidatorAgent(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=2, verbose=True):
        super().__init__(name="WriteArticleValidatorAgent", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self, topic, article):
        sys_msg = "You are an AI assistant that validates research articles."

        usr_msg = f"""
            Given the topic and the article, assess whether the article comprehensively covers the topic, follows a logical structure, and maintains academic standards.
            Provide a brief analysis and rate the article on a scale of 1 to 5, where 5 indicates excellent quality.

            Topic: 
            -------------------------------------------
            {topic}

            
            Article:
            -------------------------------------------
            {article}


            Validation:
            -------------------------------------------

        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]

        validation = self.call_model(messages, max_tokens=130000)
        return validation