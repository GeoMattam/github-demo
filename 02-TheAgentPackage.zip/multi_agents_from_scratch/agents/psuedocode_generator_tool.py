# agents/summarize_agent.py

from .agent_base import AgentBase

class PsuedoCodeGeneratorTool(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="PsuedocodeGeneratorTool", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    '''
    (
        "You have been asked to document code present between triple backticks."
        "You are not to return the code itself, but rather a detailed explanation of the code."
        f"The code you must document and explain is: ```{code}```"
        "Make sure to include explanations for all functions, classes, and key logic in the file."
        "Do not wrap the output in a code block.  Do not start your document with a heading; one will automatically be added."
    )
    '''

    '''
    Take the COBOL code present between triple backticks as input and analyze its syntax to extract business logic. The goal is 
    to preserve the intent of the code while removing COBOL-specific syntax.

    First, parse the COBOL code and identify key elements such as:

    * DIVISION structures (IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE)
    * PERFORM statements with conditionals (IF, EVALUATE) and loops (PERFORM UNTIL)
    * File I/O operations (OPEN, READ, WRITE, CLOSE)
    * Data transformations and computations

    Next, extract and summarize the business logic from the COBOL code. This includes identifying:

    * Decision-making processes
    * Loop controls and iterations
    * Data input/output operations
    * Transformations and calculations

    The output should be structured pseudo-code in a modern, readable format (structured English). Ensure that the pseudo-code is modular, 
    mapping COBOL paragraphs and sections to logical functions.

    To achieve this, consider the following characteristics:

    * Use clear and concise language
    * Organize code into logical functions and modules
    * Avoid unnecessary complexity
    * Preserve the original intent and functionality of the COBOL code

    After generating the pseudo-code, provide an option to export the extracted business logic and pseudo-code in Markdown format. 
    This will enable easy sharing and documentation of the modified COBOL code.

    The final output should be:

    1. A high-level summary of the extracted business logic, highlighting key decision-making processes, loop controls, data transformations, and calculations.
    2. Structured pseudo-code in a modern, readable format, mapping COBOL paragraphs and sections to logical functions.
    3. An option to export the extracted business logic and pseudo-code in Markdown format for easy sharing and documentation.

    **Evaluation Criteria:**

    * Accuracy and correctness of the extracted business logic
    * Clarity and readability of the generated pseudo-code
    * Effectiveness in preserving the original intent and functionality of the COBOL code
    * Ease of use and maintainability of the output

    **Input**
    ```{code}```
    '''
    def execute(self, code):
        system_message = """
        You are a top tier software developer skilled at writing pusedo code.
        """

        user_message = f"""
        Convert the following COBOL code into readable pseudo-code, keeping business logic intact:
        ```cobol
        {code}
        ```
        Format the output as Structured pseudo-code in a modern, readable format, mapping COBOL paragraphs and sections to logical functions.
        """

        messages = [
            {
                "role": "system", 
                "content": system_message
            },
            {
                "role": "user",
                "content": user_message
            }
        ]
        summary = self.call_model(messages, max_tokens=130000)
        
        return summary