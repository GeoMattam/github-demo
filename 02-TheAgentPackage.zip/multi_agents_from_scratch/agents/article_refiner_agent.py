# agents/refiner_agent.py

from .agent_base import AgentBase

class ArticleRefinerAgent(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=2, verbose=True):
        super().__init__(name="RefinerAgent", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self, draft):
        sys_msg = "You are an expert editor who refines and enhances research articles for clarity, coherence, and academic quality."
        
        usr_msg = f"""
        Please refine the following research article draft to improve its language, coherence, and overall quality:
        {draft}

        Refined Article:
        -------------------------------------------
        
        """

        messages = [
            { "role": "system", "content": sys_msg },
            { "role": "user", "content": usr_msg }
        ]

        refined_article = self.call_model(
            messages=messages,
            temperature=0.5,
            max_tokens=130000,
        )

        return refined_article