# agents/summarize_agent.py

from .agent_base import AgentBase

class MetaPromptGeneratorTool(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="MetaPromptGeneratorTool", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self, intent):
        messages = [
            {
                "role": "system", 
                "content": (
                    "You are a top prompt engineer who is skilled at generating prompts."
                )
            },
            {
                "role": "user",
                "content": intent
            }
        ]
        
        prompt = self.call_model(messages, max_tokens=130000)
        return prompt