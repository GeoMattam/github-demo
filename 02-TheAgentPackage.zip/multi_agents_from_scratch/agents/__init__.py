# agents/__init__.py

from .summarize_tool import SummarizeTool
from .summarize_validator_agent import SummarizeValidatorAgent
from .psuedocode_generator_tool import PsuedoCodeGeneratorTool
from .meta_prompt_generator_tool import MetaPromptGeneratorTool
from .source_code_documentor_tool import SourceCodeGeneratorTool
from .write_article_tool import WriteArticleTool
from .article_refiner_agent import ArticleRefinerAgent
from .write_article_validator_agent import WriteArticleValidatorAgent

class AgentManager:
    def __init__(self, max_retries=2, verbose=True):
        self.agents = {
            "summarize": SummarizeTool(provider="ollama", model="mistral", max_retries=max_retries, verbose=verbose),
            "summarize_validator": SummarizeValidatorAgent(provider="ollama", model="mistral", max_retries=max_retries, verbose=verbose),
            "psuedocode_from_sourcecode": PsuedoCodeGeneratorTool(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "sourcecode_documentor": SourceCodeGeneratorTool(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "generate_prompt": MetaPromptGeneratorTool(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "write_article": WriteArticleTool(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "refine_article": ArticleRefinerAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
            "article_validator": WriteArticleValidatorAgent(provider="google", model="default", max_retries=max_retries, verbose=verbose),
        }

    def get_agent(self, agent_name):
        agent = self.agents.get(agent_name)
        if not agent:
            raise ValueError(f"Agent '{agent_name}' not found.")
        return agent