# agents/write_article_agent.py

from .agent_base import AgentBase

class WriteArticleTool(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="WriteArticleTool", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self, topic, outline=None):
        sys_msg = "You are an expert academic writer."

        usr_msg = f"""
        Write a research article on the following topic:

        Topic: 
        -------------------------------------------
        {topic}

        """

        if outline:
            usr_msg += f"""
            Outline: 
            -------------------------------------------
            {outline}

            """

        usr_msg += """
        Article:
        -------------------------------------------

        """

        messages = [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": usr_msg}
        ]
        
        article = self.call_model(messages, max_tokens=130000)

        return article