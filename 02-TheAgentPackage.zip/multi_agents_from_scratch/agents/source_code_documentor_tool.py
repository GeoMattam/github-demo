# agents/summarize_agent.py

from .agent_base import AgentBase

"""

You have been asked to document code in a project.

You are not to return the code itself, but rather a detailed explanation of the code.

Make sure to include explanations for all functions, classes, and key logic in the file.
Make sure to include explanations for all DIVISION structures (IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE), PERFORM statements with conditionals (IF, EVALUATE) and loops (PERFORM UNTIL), 
File I/O operations (OPEN, READ, WRITE, CLOSE), Data transformations and computations
Make sure to include explanations for all Decision-making processes, Loop controls and iterations, Data input/output operations, Transformations and calculations

Do not wrap the output in a code block.  

Contents:
----------------------------------------
```{code}```

"""
class SourceCodeGeneratorTool(AgentBase):
    def __init__(self, provider="ollama", model="llama3.2", max_retries=3, verbose=True):
        super().__init__(name="SourceCodeGeneratorTool", provider=provider, model=model, max_retries=max_retries, verbose=verbose)

    def execute(self, code):
        system_message = """
        You are a top tier software developer skilled at docomenting and explaining code.
        """

        user_message = f"""
        Analyze the following COBOL code and extract its core business logic, converting the procedural code into structured pseudo-code.  Prioritize clarity, accuracy, and maintainability in the output to facilitate modernization efforts.

        **Input COBOL Code:**  
        ```{code}```


        **Instructions:**

        1. **Parsing and Understanding:**  Parse the provided COBOL code, understanding its structure and functionality.  Pay close attention to the following COBOL elements:

            * **DIVISION Structure:**  Identify and process the IDENTIFICATION, ENVIRONMENT, DATA, and PROCEDURE DIVISION sections.
            * **Control Structures:**  Accurately interpret `PERFORM` statements (including `PERFORM UNTIL`), conditional statements (`IF`, `EVALUATE`), and loops.
            * **File I/O:**  Recognize and understand file handling operations (`OPEN`, `READ`, `WRITE`, `CLOSE`).
            * **Data Manipulation:**  Analyze data transformations, computations, and assignments.

        2. **Business Logic Extraction:**  Extract the essential business logic from the COBOL code, summarizing its purpose and functionality in plain language.  Focus on the *what* and *why* of the code, not just the *how*.  Avoid unnecessary detail and focus on the core processes.

        3. **Pseudo-code Generation:**  Generate structured pseudo-code representing the extracted business logic.  Aim for a modern, readable format resembling Python or structured English.  Use functions or procedures to modularize the code, mirroring the structure of COBOL paragraphs and sections.  For example:

            ```python
            def calculate_total_amount(items):
                total = 0
                for item in items:
                    total += item.price * item.quantity
                return total
            ```

        4. **Modularization:**  Organize the pseudo-code into logical modules or functions, clearly mapping each COBOL paragraph or section to a corresponding pseudo-code function.  Provide clear function names reflecting their purpose.

        5. **Output Format:**  Present your analysis and pseudo-code in a clear and organized manner.  Include the following:

            * **Business Logic Summary:** A concise description of the overall business logic.
            * **Pseudo-code:** The structured pseudo-code representation.
            * **Mapping:** A table or description mapping COBOL paragraphs/sections to their corresponding pseudo-code functions.

        6. **Markdown Export (Optional):** If possible, format the output as a Markdown file (.md) for easy readability and sharing.  The Markdown should include properly formatted code blocks for both the original COBOL and the generated pseudo-code.


        **Example Output (Markdown):**

        ```markdown
        # COBOL Code Analysis and Pseudo-code Conversion

        ## Business Logic Summary:

        This COBOL program processes customer orders, calculating the total amount due and writing the order details to a file.


        ## Pseudo-code:

        ```python
        def process_order(order_data):
        # ... (pseudo-code for order processing) ...
        ```

        ## Mapping:

        | COBOL Paragraph/Section | Pseudo-code Function | Description |
        |---|---|---|
        | `PROCESS-ORDER` | `process_order()` | Processes a single customer order |
        | `CALCULATE-TOTAL` | `calculate_total_amount()` | Calculates the total amount due for the order |
        | `WRITE-ORDER-DETAILS` | `write_order_details()` | Writes order details to the output file |

        ```


        By following these instructions, you will provide a valuable tool for understanding and modernizing legacy COBOL applications.  Focus on producing high-quality, human-readable output that accurately reflects the intent of the original COBOL code.
        """

        messages = [
            {
                "role": "system", 
                "content": system_message
            },
            {
                "role": "user",
                "content": user_message
            }
        ]
        
        summary = self.call_model(messages, max_tokens=130000)
        return summary