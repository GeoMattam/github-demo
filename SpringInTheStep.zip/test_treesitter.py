# from tree_sitter import Language

# # This will create a shared library with the Java parser
# Language.build_library(
#     'build/my-languages.so',
#     [
#         'tree-sitter-java'  # path to the Java grammar you cloned
#     ]
# )

import tree_sitter_java as tsjava
from tree_sitter import Language, Parser

JAVA_LANGUAGE = Language(tsjava.language())
parser = Parser(JAVA_LANGUAGE)