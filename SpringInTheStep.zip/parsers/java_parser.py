import re

import tree_sitter_java as tsjava
from tree_sitter import Language, Parser

JAVA_LANGUAGE = Language(tsjava.language())
parser = Parser(JAVA_LANGUAGE)

# Basic version using regex - we’ll replace this regex version with Tree-sitter for deeper parsing.
# def parse_java_file(file_path):
#     with open(file_path, 'r', encoding='utf-8') as f:
#         code = f.read()
    
#     class_name = re.findall(r'public\s+(?:class|interface)\s+(\w+)', code)
#     annotations = re.findall(r'@\w+', code)
#     methods = re.findall(r'(public|private|protected)\s+\w+\s+(\w+)\(.*?\)', code)

#     return {
#         "file": file_path,
#         "class_name": class_name[0] if class_name else "Unknown",
#         "annotations": annotations,
#         "methods": [{"visibility": vis, "name": name} for vis, name in methods]
#     }

def classify_component(annotations, class_name):
    mapping = {
        "@RestController": "Controller",
        "@Controller": "Controller",
        "@Service": "Service",
        "@Repository": "Repository",
        "@Component": "Component",
        "@Configuration": "Configuration",
        "@Interface": "Interface",        
        "@SpringBootApplication": "Application",
        "@Entity": "Entity",
        # Test annotations
        "@SpringBootTest": "Test",
        "@WebMvcTest": "WebTest",
        "@DataJpaTest": "JpaTest",
        "@JdbcTest": "JdbcTest",
        "@MockBean": "MockTest",
        "@TestConfiguration": "TestConfig"
    }
    roles = [mapping[ann] for ann in annotations if ann in mapping]

    # Detect DTO by naming convention
    if not roles and class_name:
        if class_name.endswith(("DTO", "Request", "Response")):
            roles.append("DTO")

    return roles

def parse_java_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        code = f.read()

    tree = parser.parse(bytes(code, 'utf8'))
    root_node = tree.root_node

    result = {
        "file": file_path,
        "class_name": None,
        "annotations": [],
        "methods": [],
        "component_type": [],
        "fields": [],
        "calls": [],
        "interfaces": []
    }

    field_vars = {}
    current_class_annotations = []
    method_annotations = []

    def get_text(node):
        return code[node.start_byte:node.end_byte]

    def extract_info(node):
        # print(f"Node type: {node.type}")  # Add this line to debug and check
        nonlocal field_vars, current_class_annotations, method_annotations

        # Collect top-level annotations
        if node.type == 'annotation' or node.type == 'marker_annotation':
            annotation = get_text(node)
            # print("Detected annotation:", annotation)  # <-- Add this line to debug and check
            current_class_annotations.append(annotation)

            if annotation.startswith('@GetMapping') or annotation.startswith('@PostMapping') or \
               annotation.startswith('@PutMapping') or annotation.startswith('@DeleteMapping'):
                method_annotations.append(annotation)

        elif node.type == 'class_declaration': # or node.type == 'interface_declaration':
            class_name = None
            current_class_annotations = []  # reset for this class
            is_application = False
            has_fields = False
            has_methods = False

            for child in node.children:
                if child.type == 'modifiers':
                    for grandchild in child.children:
                        if grandchild.type in ("marker_annotation", "annotation"):
                            annotation = get_text(grandchild)
                            # print("Detected annotation:", annotation) # Add this line to debug and check
                            current_class_annotations.append(annotation)

                if child.type == 'identifier':
                    class_name = get_text(child)
                    result["class_name"] = class_name

                elif child.type == 'superclass':
                    superclass = child.child_by_field_name("name")
                    if superclass and get_text(superclass) == 'SpringBootServletInitializer':
                        is_application = True

                elif child.type == 'class_body':
                    for body_child in child.children:
                        if body_child.type == 'field_declaration':
                            has_fields = True
                        elif body_child.type == 'method_declaration':
                            has_methods = True

            # print(f"Processing class: {class_name}") # Add this line to debug and check
            # print(f"Class annotations: {current_class_annotations}") # Add this line to debug and check
            result["annotations"] = current_class_annotations

            roles = classify_component(current_class_annotations, class_name)

            if is_application and "Application" not in roles:
                roles.append("Application")

            # Detect POJO
            if not roles and has_fields and has_methods:
                roles.append("POJO")

            result["component_type"] = list(set(roles)) if roles else ["Unknown"]

        elif node.type == 'interface_declaration':
            class_name = None
            extends_jpa = False

            for child in node.children:
                if child.type == 'identifier':
                    class_name = get_text(child)
                    result["class_name"] = class_name

                elif child.type == 'super_interfaces':
                    for iface in child.named_children:
                        iface_name = get_text(iface)
                        if iface_name in ["JpaRepository", "CrudRepository", "PagingAndSortingRepository"]:
                            extends_jpa = True

            result["annotations"] = []
            roles = ["Repository"] if extends_jpa else []

            result["component_type"] = list(set(roles)) if roles else ["Interface"]
            result["interfaces"].append(class_name)

        elif node.type == 'field_declaration':
            annotations = [get_text(c) for c in node.children if c.type == 'marker_annotation' or c.type == 'annotation']
            type_node = next((c for c in node.children if c.type == 'type_identifier'), None)
            name_node = next((c for c in node.children if c.type == 'variable_declarator'), None)
            if type_node and name_node:
                var_name_node = name_node.child_by_field_name("name")
                if var_name_node:
                    var_name = get_text(var_name_node)
                    class_type = get_text(type_node)
                    result["fields"].append({
                        "name": var_name,
                        "type": class_type,
                        "annotations": annotations
                    })
                    field_vars[var_name] = class_type

        elif node.type == 'method_declaration':
            method_name = ""
            visibility = "package-private"
            for child in node.children:
                if child.type == 'modifiers':
                    modifiers_text = get_text(child)
                    if 'public' in modifiers_text:
                        visibility = "public"
                    elif 'private' in modifiers_text:
                        visibility = "private"
                    elif 'protected' in modifiers_text:
                        visibility = "protected"
                elif child.type == 'identifier':
                    method_name = get_text(child)

            param_types = []
            return_type = None

            for child in node.children:
                if child.type == 'formal_parameters':
                    for p in child.named_children:
                        type_node = p.child_by_field_name("type")
                        if type_node:
                            param_types.append(get_text(type_node))
                elif child.type == 'type_type' or child.type == 'type_identifier':
                    return_type = get_text(child)
            
            result["methods"].append({
                "name": method_name,
                "visibility": visibility,
                "annotations": method_annotations
            })
            method_annotations = []

        elif node.type == 'method_invocation':
            receiver = node.child_by_field_name("object")
            method = node.child_by_field_name("name")
            if receiver and method:
                var = get_text(receiver)
                if var in field_vars:
                    result["calls"].append(f"{field_vars[var]}.{get_text(method)}")

        for child in node.children:
            extract_info(child)

    extract_info(root_node)
    return result

# Run the parser
if __name__ == '__main__':
    result = parse_java_file('./parsers/HelloController.java')
    from pprint import pprint
    pprint(result)