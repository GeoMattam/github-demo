"""

Uses Gemini to:
    Generate summaries of each component.
    Create architecture diagrams (PlantUML).
    Answer questions like “How does login flow work?”
    Create Markdown documentation.

"""
import os
import sys
import json
import google.generativeai as genai

# get the current directory of the file
current_dir = os.path.dirname(os.path.abspath(__file__))
# get the parent directory of the file by going one level up
parent_dir = os.path.dirname(current_dir)

# Add the parent directory to the sys path
if parent_dir not in sys.path:
    sys.path.append(parent_dir)
    
from tools.prompt_templates import ARCHITECTURE_SUMMARY_PROMPT
from rich import print

class LLMAnalystAgent:
    def __init__(self):
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("Missing GOOGLE_API_KEY for api invocation")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel("gemini-1.5-flash")
    
    def run(self, architecture_path="output/architecture.json", code_summary_path="output/code_summary.json"):
        print("[bold green]Running LLMAnalystAgent...[/bold green]")

        with open(architecture_path, "r") as f:
            architecture = json.load(f)
        
        with open(code_summary_path, "r") as f:
            code_summary = json.load(f)
        
        prompt = ARCHITECTURE_SUMMARY_PROMPT.format(
            architecture=json.dumps(architecture, indent=2),
            code_summary=json.dumps(code_summary, indent=2)
        )

        response = self.model.generate_content(prompt)
        summary = response.text

        with open("output/architecture_summary.md", "w") as f:
            f.write(summary)
        
        print("[bold blue]Summary written to output/architecture_summary.md[/bold blue]")
        return summary

# Optional direct run
if __name__ == "__main__":
    agent = LLMAnalystAgent()
    agent.run()