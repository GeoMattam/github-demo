"""

Finds and summarizes REST APIs using @RestController, @RequestMapping, etc.
Parses request/response types and HTTP verbs.

"""
import json
import re
from rich import print

class APIAgent:
    def run(self, code_summary_path="output/code_summary.json"):
        print(f"[bold green]Running APIAgent...[/bold green]")
        with open(code_summary_path, "r") as f:
            components = json.load(f)
        
        api_endpoints = []
        for comp in components:
            if len(comp["component_type"]) > 0:
                if comp["component_type"][0].upper() == "Controller".upper():
                    for method in comp.get("methods", []):
                        endpoint = {
                            "controller": comp["class_name"],
                            "method": method["name"],
                            "http_method": "GET",  # default, override below
                            "path": "/unknown"
                        }

                        # Check for annotations like @GetMapping("/path")
                        for annotation in comp["annotations"]:
                            if "Mapping" in annotation:
                                if "Get" in annotation:
                                    endpoint["http_method"] = "GET"
                                elif "Post" in annotation:
                                    endpoint["http_method"] = "POST"
                                elif "Put" in annotation:
                                    endpoint["http_method"] = "PUT"
                                elif "Delete" in annotation:
                                    endpoint["http_method"] = "DELETE"

                                # Try to extract path
                                match = re.search(r'\("(.*?)"\)', annotation)
                                if match:
                                    endpoint["path"] = match.group(1)

                        api_endpoints.append(endpoint)

        with open("output/api_endpoints.json", "w") as f:
            json.dump(api_endpoints, f, indent=2)

        print("[bold blue]API data written to output/api_endpoints.json[/bold blue]")
        return api_endpoints

# Optional direct run
if __name__ == "__main__":
    agent = APIAgent()
    agent.run()