"""

Analyzes JPA repositories and queries.
Maps entity relationships and joins.

"""
import json
from rich import print

class DataLayerAgent:
    def run(self, code_summary_path="output/code_summary.json"):
        print(f"[bold green]Running DataLayerAgent...[/bold green]")
        with open(code_summary_path, "r") as f:
            components = json.load(f)
        
        repos = []
        entities = []

        for comp in components:
            if len(comp["component_type"]) > 0:
                if comp["component_type"][0].upper() == "Repository".upper():
                    repos.append(comp["class_name"])
                elif "@Entity" in comp.get("annotations", []):
                    entities.append(comp["class_name"])

        output = {
            "repositories": repos,
            "entities": entities
        }

        with open("output/data_layer_summary.json", "w") as f:
            json.dump(output, f, indent=2)

        print("[bold blue]Data layer summary written to output/data_layer_summary.json[/bold blue]")
        return output

# Optional direct run
if __name__ == "__main__":
    agent = DataLayerAgent()
    agent.run()