ARCHITECTURE_SUMMARY_PROMPT = """
You are a senior software architect. Based on the following Spring Boot code and architecture data, generate:

1. A high-level description of the application's layers and components.
2. How controllers interact with services and repositories.
3. Any notable flows or design patterns.
4. Important observations about the architecture.

ARCHITECTURE:
{architecture}

CODE SUMMARY:
{code_summary}
"""