import json
import os
from rich import print

def generate_plantuml(architecture_path="output/architecture.json", output_path="output/architecture.puml"):
    with open(architecture_path, "r") as f:
        data = json.load(f)
    
    types = data["component_types"]
    calls = data["call_graph"]
    roles = data["name_to_type"]

    lines = [
        "@startuml",
        "skinparam componentStyle rectangle",
        ""
    ]

    # Group by type
    for comp_type, class_list in types.items():
        lines.append(f"package {comp_type} {{")
        for cls in class_list:
            lines.append(f'  component {cls}')
        lines.append("}")

    lines.append("")

    # Add connections
    for caller, callees in calls.items():
        for callee in callees:
            lines.append(f"{caller} --> {callee}")

    lines.append("@enduml")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w") as f:
        f.write("\n".join(lines))

    print(f"[bold blue]PlantUML diagram written to {output_path}[/bold blue]")

# Run the parser
if __name__ == '__main__':
    generate_plantuml("output/architecture.json", "output/architecture.puml")