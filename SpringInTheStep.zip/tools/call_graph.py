import json
import networkx as nx
from pyvis.network import Network

def generate_call_graph_html(json_path="output/architecture.json", output_html="output/call_graph.html"):
    with open(json_path) as f:
        data = json.load(f)

    G = nx.DiGraph()
    types = data["name_to_type"]
    calls = data["call_graph"]

    for node, node_type in types.items():
        G.add_node(node, title=node_type, group=node_type)

    for caller, callees in calls.items():
        for callee in callees:
            G.add_edge(caller, callee)

    net = Network(height="600px", width="100%", directed=True)
    net.from_nx(G)
    net.save_graph(output_html)