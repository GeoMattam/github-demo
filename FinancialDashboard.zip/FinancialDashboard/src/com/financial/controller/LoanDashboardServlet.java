package com.financial.controller;

import com.financial.dao.LoanApplicationDAO;
import com.financial.model.LoanApplication;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class LoanDashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            LoanApplicationDAO dao = new LoanApplicationDAO();
            List<LoanApplication> apps = dao.getAllApplications();
            request.setAttribute("loanApplications", apps);
        } catch (Exception e) {
            e.printStackTrace();
        }
        request.getRequestDispatcher("/loanDashboard.jsp").forward(request, response);
    }
}