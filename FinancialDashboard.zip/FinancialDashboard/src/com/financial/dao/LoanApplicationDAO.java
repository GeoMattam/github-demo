package com.financial.dao;

import com.financial.model.LoanApplication;
import java.sql.*;
import java.util.*;

public class LoanApplicationDAO {
    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/finance_db", "root", "password");
    }

    public List<LoanApplication> getAllApplications() throws Exception {
        List<LoanApplication> apps = new ArrayList<>();
        String sql = "SELECT * FROM loan_applications";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                apps.add(new LoanApplication(
                    rs.getString("application_id"),
                    rs.getString("applicant_name"),
                    rs.getDouble("amount"),
                    rs.getString("status")));
            }
        }
        return apps;
    }
}