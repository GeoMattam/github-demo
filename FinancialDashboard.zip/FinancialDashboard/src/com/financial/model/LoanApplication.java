package com.financial.model;

public class LoanApplication {
    private String applicationId;
    private String applicantName;
    private double amount;
    private String status;

    public LoanApplication(String id, String name, double amount, String status) {
        this.applicationId = id;
        this.applicantName = name;
        this.amount = amount;
        this.status = status;
    }

    public String getApplicationId() { return applicationId; }
    public String getApplicantName() { return applicantName; }
    public double getAmount() { return amount; }
    public String getStatus() { return status; }
}